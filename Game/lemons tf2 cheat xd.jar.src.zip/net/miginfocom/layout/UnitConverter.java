package net.miginfocom.layout;

public abstract class UnitConverter {
  public static final int UNABLE = -87654312;
  
  public abstract int convertToPixels(float paramFloat1, String paramString, boolean paramBoolean, float paramFloat2, ContainerWrapper paramContainerWrapper, ComponentWrapper paramComponentWrapper);
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\net\miginfocom\layout\UnitConverter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.4
 */