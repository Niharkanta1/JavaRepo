package net.miginfocom.layout;

public interface InCellGapProvider {
  BoundSize getDefaultGap(ComponentWrapper paramComponentWrapper1, ComponentWrapper paramComponentWrapper2, int paramInt, String paramString, boolean paramBoolean);
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\net\miginfocom\layout\InCellGapProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.4
 */