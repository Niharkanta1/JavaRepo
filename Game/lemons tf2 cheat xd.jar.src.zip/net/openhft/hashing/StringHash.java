package net.openhft.hashing;

interface StringHash {
  long longHash(String paramString, LongHashFunction paramLongHashFunction, int paramInt1, int paramInt2);
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\net\openhft\hashing\StringHash.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */