/*    */ package com.beaudoin.jmm;
/*    */ 
/*    */ import com.beaudoin.jmm.process.NativeProcess;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Main
/*    */ {
/* 37 */   public static void main(String[] args) throws IOException { NativeProcess proc = NativeProcess.byName("C__Stuff.exe"); }
/*    */ }


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\beaudoin\jmm\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */