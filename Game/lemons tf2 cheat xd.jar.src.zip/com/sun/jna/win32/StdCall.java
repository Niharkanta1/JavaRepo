package com.sun.jna.win32;

import com.sun.jna.AltCallingConvention;

public interface StdCall extends AltCallingConvention {}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\sun\jna\win32\StdCall.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */