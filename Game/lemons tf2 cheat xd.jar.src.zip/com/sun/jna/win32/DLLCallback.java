package com.sun.jna.win32;

import com.sun.jna.Callback;

public interface DLLCallback extends Callback {
  public static final int DLL_FPTRS = 16;
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\sun\jna\win32\DLLCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */