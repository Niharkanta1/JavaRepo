package com.sun.jna;

import java.lang.reflect.Method;

public interface FunctionMapper {
  String getFunctionName(NativeLibrary paramNativeLibrary, Method paramMethod);
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\sun\jna\FunctionMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */