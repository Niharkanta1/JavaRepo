package com.sun.jna.platform.win32;

import com.sun.jna.win32.StdCallLibrary;

public interface GL extends StdCallLibrary {
  public static final int GL_VENDOR = 7936;
  
  public static final int GL_RENDERER = 7937;
  
  public static final int GL_VERSION = 7938;
  
  public static final int GL_EXTENSIONS = 7939;
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\sun\jna\platform\win32\GL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */