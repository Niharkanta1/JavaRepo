package com.sun.jna.platform.win32.COM.util;

import com.sun.jna.platform.win32.COM.util.annotation.ComInterface;

@ComInterface(iid = "{B196B284-BAB4-101A-B69C-00AA00341D07}")
public interface IConnectionPointContainer extends IRawDispatchHandle {}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\sun\jna\platform\win32\CO\\util\IConnectionPointContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */