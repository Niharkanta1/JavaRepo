package com.sun.jna.platform.win32.COM;

public interface IDispatchCallback extends IDispatch, IUnknownCallback {}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\sun\jna\platform\win32\COM\IDispatchCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */