/*    */ package com.sun.jna.platform.win32.COM.tlb.imp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TlbParameterNotFoundException
/*    */   extends RuntimeException
/*    */ {
/*    */   public TlbParameterNotFoundException() {}
/*    */   
/* 21 */   public TlbParameterNotFoundException(String msg) { super(msg); }
/*    */ 
/*    */ 
/*    */   
/* 25 */   public TlbParameterNotFoundException(Throwable cause) { super(cause); }
/*    */ 
/*    */ 
/*    */   
/* 29 */   public TlbParameterNotFoundException(String msg, Throwable cause) { super(msg, cause); }
/*    */ }


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\sun\jna\platform\win32\COM\tlb\imp\TlbParameterNotFoundException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */