package com.sun.jna.platform.win32;

public interface FlagEnum {
  int getFlag();
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\sun\jna\platform\win32\FlagEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */