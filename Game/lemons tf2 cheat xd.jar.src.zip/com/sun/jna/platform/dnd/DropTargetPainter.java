package com.sun.jna.platform.dnd;

import java.awt.Point;
import java.awt.dnd.DropTargetEvent;

public interface DropTargetPainter {
  void paintDropTarget(DropTargetEvent paramDropTargetEvent, int paramInt, Point paramPoint);
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\com\sun\jna\platform\dnd\DropTargetPainter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */