/*    */ package me.lemon.lemonware.feature.features;
/*    */ 
/*    */ import lc.kra.system.keyboard.event.GlobalKeyEvent;
/*    */ import me.lemon.lemonware.feature.Feature;
/*    */ import me.lemon.lemonware.tf2.LocalPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlowESP
/*    */   extends Feature
/*    */ {
/* 15 */   public GlowESP() { super("glow", Feature.FeatureType.VISUAL); }
/*    */   
/*    */   public void run(LocalPlayer local) {}
/*    */   
/*    */   public void onKeyPress(GlobalKeyEvent event) {}
/*    */   
/*    */   public void onKeyRelease(GlobalKeyEvent event) {}
/*    */ }


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\me\lemon\lemonware\feature\features\GlowESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */