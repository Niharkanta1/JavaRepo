/*    */ package me.lemon.lemonware.utils.vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Vector2f
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   
/* 11 */   public float getX() { return this.x; } public float getY() { return this.y; } public void setX(float x) { this.x = x; } public void setY(float y) { this.y = y; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector2f() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector2f(float x, float y) {
/* 24 */     this.x = x;
/* 25 */     this.y = y;
/*    */   }
/*    */ }


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\me\lemon\lemonwar\\utils\vector\Vector2f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */