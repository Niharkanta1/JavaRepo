/*    */ package me.lemon.lemonware.utils.vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Vector3f
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   public float z;
/*    */   
/* 11 */   public float getX() { return this.x; } public float getY() { return this.y; } public float getZ() { return this.z; } public void setX(float x) { this.x = x; } public void setY(float y) { this.y = y; } public void setZ(float z) { this.z = z; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector3f() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector3f(float x, float y, float z) {
/* 25 */     this.x = x;
/* 26 */     this.y = y;
/* 27 */     this.z = z;
/*    */   }
/*    */ }


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\me\lemon\lemonwar\\utils\vector\Vector3f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */