package lombok;

public @interface val {}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\lombok\val.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.4
 */