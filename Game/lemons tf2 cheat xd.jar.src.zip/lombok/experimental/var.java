package lombok.experimental;

public @interface var {}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\lombok\experimental\var.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.4
 */