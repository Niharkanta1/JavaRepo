package lc.kra.system.mouse.event;

public class GlobalMouseAdapter implements GlobalMouseListener {
  public void mousePressed(GlobalMouseEvent event) {}
  
  public void mouseReleased(GlobalMouseEvent event) {}
  
  public void mouseMoved(GlobalMouseEvent event) {}
  
  public void mouseWheel(GlobalMouseEvent event) {}
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\lc\kra\system\mouse\event\GlobalMouseAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */