package lc.kra.system.keyboard.event;

public class GlobalKeyAdapter implements GlobalKeyListener {
  public void keyPressed(GlobalKeyEvent event) {}
  
  public void keyReleased(GlobalKeyEvent event) {}
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\lc\kra\system\keyboard\event\GlobalKeyAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */