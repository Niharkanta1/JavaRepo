package lc.kra.system.keyboard.event;

import java.util.EventListener;

public interface GlobalKeyListener extends EventListener {
  void keyPressed(GlobalKeyEvent paramGlobalKeyEvent);
  
  void keyReleased(GlobalKeyEvent paramGlobalKeyEvent);
}


/* Location:              D:\CODING\JAVA\Game\lemons tf2 cheat xd.jar!\lc\kra\system\keyboard\event\GlobalKeyListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.4
 */