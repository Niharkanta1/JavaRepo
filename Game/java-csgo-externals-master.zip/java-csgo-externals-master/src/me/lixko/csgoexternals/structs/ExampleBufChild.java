package me.lixko.csgoexternals.structs;

import me.lixko.csgoexternals.util.BufferStruct;

public class ExampleBufChild extends BufferStruct {
	public int x = 100, y = 110;
}
