package me.lixko.csgoexternals.offsets;

public enum AttributableItemType {
	AUTOMATIC,
	SNIPER,
	SHOTGUN,
	PISTOL,
	GRENADE,
	KNIFE,
	OTHER;
}