package me.lixko.csgoexternals.offsets;

public class Netvars { 
	public static class CChicken { // DT_CChicken
		public static final long m_jumpedThisFrame = 0x305c; // int
		public static final long m_leader = 0x3060; // int
	}

	public static class CFireCrackerBlast { // DT_FireCrackerBlast
	}

	public static class CInferno { // DT_Inferno
		public static final long m_fireXDelta = 0xf80; // int[99] / m_fireXDelta
		public static final long m_fireYDelta = 0x1110; // int[99] / m_fireYDelta
		public static final long m_fireZDelta = 0x12a0; // int[99] / m_fireZDelta
		public static final long m_bFireIsBurning = 0x1430; // int[99] / m_bFireIsBurning
		public static final long m_fireCount = 0x1944; // int
	}

	public static class CItemDogtags { // DT_ItemDogtags
		public static final long m_OwningPlayer = 0x3e88; // int
		public static final long m_KillingPlayer = 0x3e8c; // int
	}

	public static class CSensorGrenadeProjectile { // DT_SensorGrenadeProjectile
	}

	public static class CItem_Healthshot { // DT_Item_Healthshot
	}

	public static class CWeaponBaseItem { // DT_WeaponBaseItem
		public static final long m_bRedraw = 0x3c18; // int
	}

	public static class CSmokeGrenadeProjectile { // DT_SmokeGrenadeProjectile
		public static final long m_bDidSmokeEffect = 0x3058; // int
		public static final long m_nSmokeEffectTickBegin = 0x3054; // int
	}

	public static class CDecoyProjectile { // DT_DecoyProjectile
	}

	public static class CMolotovProjectile { // DT_MolotovProjectile
		public static final long m_bIsIncGrenade = 0x3054; // int
	}

	public static class CWeaponNOVA { // DT_WeaponNOVA
		public static final long m_reloadState = 0x3c08; // int
	}

	public static class CSensorGrenade { // DT_SensorGrenade
	}

	public static class CDecoyGrenade { // DT_DecoyGrenade
	}

	public static class CIncendiaryGrenade { // DT_IncendiaryGrenade
	}

	public static class CMolotovGrenade { // DT_MolotovGrenade
	}

	public static class CWeaponTaser { // DT_WeaponTaser
		public static final long m_fFireTime = 0x3c24; // float
	}

	public static class CWeaponSawedoff { // DT_WeaponSawedoff
		public static final long m_reloadState = 0x3c08; // int
	}

	public static class CWeaponXM1014 { // DT_WeaponXM1014
		public static final long m_reloadState = 0x3c08; // int
	}

	public static class CSmokeGrenade { // DT_SmokeGrenade
	}

	public static class CWeaponSG552 { // DT_WeaponSG552
	}

	public static class CWeaponM3 { // DT_WeaponM3
		public static final long m_reloadState = 0x3c08; // int
	}

	public static class CKnifeGG { // DT_WeaponKnifeGG
	}

	public static class CKnife { // DT_WeaponKnife
	}

	public static class CHEGrenade { // DT_HEGrenade
	}

	public static class CFlashbang { // DT_Flashbang
	}

	public static class CWeaponElite { // DT_WeaponElite
	}

	public static class CDEagle { // DT_WeaponDEagle
	}

	public static class CWeaponUSP { // DT_WeaponUSP
	}

	public static class CWeaponM249 { // DT_WeaponM249
	}

	public static class CWeaponUMP45 { // DT_WeaponUMP45
	}

	public static class CWeaponTMP { // DT_WeaponTMP
	}

	public static class CWeaponTec9 { // DT_WeaponTec9
	}

	public static class CWeaponSSG08 { // DT_WeaponSSG08
	}

	public static class CWeaponSG556 { // DT_WeaponSG556
	}

	public static class CWeaponSG550 { // DT_WeaponSG550
	}

	public static class CWeaponScout { // DT_WeaponScout
	}

	public static class CWeaponSCAR20 { // DT_WeaponSCAR20
	}

	public static class CSCAR17 { // DT_WeaponSCAR17
	}

	public static class CWeaponP90 { // DT_WeaponP90
	}

	public static class CWeaponP250 { // DT_WeaponP250
	}

	public static class CWeaponP228 { // DT_WeaponP228
	}

	public static class CWeaponNegev { // DT_WeaponNegev
	}

	public static class CWeaponMP9 { // DT_WeaponMP9
	}

	public static class CWeaponMP7 { // DT_WeaponMP7
	}

	public static class CWeaponMP5Navy { // DT_WeaponMP5Navy
	}

	public static class CWeaponMag7 { // DT_WeaponMag7
	}

	public static class CWeaponMAC10 { // DT_WeaponMAC10
	}

	public static class CWeaponM4A1 { // DT_WeaponM4A1
	}

	public static class CWeaponHKP2000 { // DT_WeaponHKP2000
	}

	public static class CWeaponGlock { // DT_WeaponGlock
	}

	public static class CWeaponGalilAR { // DT_WeaponGalilAR
	}

	public static class CWeaponGalil { // DT_WeaponGalil
	}

	public static class CWeaponG3SG1 { // DT_WeaponG3SG1
	}

	public static class CWeaponFiveSeven { // DT_WeaponFiveSeven
	}

	public static class CWeaponFamas { // DT_WeaponFamas
	}

	public static class CWeaponBizon { // DT_WeaponBizon
	}

	public static class CWeaponAWP { // DT_WeaponAWP
	}

	public static class CWeaponAug { // DT_WeaponAug
	}

	public static class CAK47 { // DT_WeaponAK47
	}

	public static class CWeaponCSBaseGun { // DT_WeaponCSBaseGun
		public static final long m_zoomLevel = 0x3c04; // int
		public static final long m_iBurstShotsRemaining = 0x3c08; // int
	}

	public static class CWeaponCSBase { // DT_WeaponCSBase
		public static final long m_weaponMode = 0x3b68; // int
		public static final long m_fAccuracyPenalty = 0x3b6c; // float
		public static final long m_fLastShotTime = 0x3be0; // float
		public static final long m_iRecoilIndex = 0x3b78; // int
		public static final long m_flRecoilIndex = 0x3b7c; // float
		public static final long m_hPrevOwner = 0x3bac; // int
		public static final long m_bBurstMode = 0x3b80; // int
		public static final long m_flPostponeFireReadyTime = 0x3b84; // float
		public static final long m_bReloadVisuallyComplete = 0x3b88; // int
		public static final long m_bSilencerOn = 0x3b89; // int
		public static final long m_flDoneSwitchingSilencer = 0x3b8c; // float
		public static final long m_iOriginalTeamNumber = 0x3b94; // int
		public static final long m_iIronSightMode = 0x3c00; // int
	}

	public static class CC4 { // DT_WeaponC4
		public static final long m_bStartedArming = 0x3c44; // int
		public static final long m_bBombPlacedAnimation = 0x3c4c; // int
		public static final long m_fArmedTime = 0x3c48; // float
		public static final long m_bShowC4LED = 0x3c4d; // int
		public static final long m_bIsPlantingViaUse = 0x3c4e; // int
	}

	public static class CBaseCSGrenade { // DT_BaseCSGrenade
		public static final long m_bRedraw = 0x3c04; // int
		public static final long m_bIsHeldByPlayer = 0x3c05; // int
		public static final long m_bPinPulled = 0x3c06; // int
		public static final long m_fThrowTime = 0x3c08; // float
		public static final long m_bLoopingSoundPlaying = 0x3c0c; // int
		public static final long m_flThrowStrength = 0x3c10; // float
	}

	public static class CFootstepControl { // DT_FootstepControl
		public static final long m_source = 0xf92; // const char *
		public static final long m_destination = 0xfa2; // const char *
	}

	public static class CCSGameRulesProxy { // DT_CSGameRulesProxy
		public static class DT_CSGameRules { // m_arrTournamentActiveCasterAccounts
		}

		public static final long DT_CSGameRules = 0x0; // DataTable[80] / cs_gamerules_data
	}

	public static class CWeaponCubemap { // DT_WeaponCubemap
	}

	public static class CWeaponCycler { // DT_WeaponCycler
	}

	public static class CTEPlantBomb { // DT_TEPlantBomb
		public static final long m_iPlayer = 0x20; // int
		public static final long m_option = 0x30; // int
	}

	public static class CTEFireBullets { // DT_TEFireBullets
		public static final long m_vecAngles_0 = 0x34; // float
		public static final long m_vecAngles_1 = 0x38; // float
		public static final long m_iWeaponID = 0x44; // int
		public static final long m_weapon = 0x40; // int
		public static final long m_iMode = 0x48; // int
		public static final long m_iSeed = 0x4c; // int
		public static final long m_iPlayer = 0x20; // int
		public static final long m_fInaccuracy = 0x50; // float
		public static final long m_fSpread = 0x58; // float
		public static final long m_nItemDefIndex = 0x24; // int
		public static final long m_iSoundType = 0x5c; // int
		public static final long m_flRecoilIndex = 0x54; // float
	}

	public static class CTERadioIcon { // DT_TERadioIcon
		public static final long m_iAttachToClient = 0x20; // int
	}

	public static class CPlantedC4 { // DT_PlantedC4
		public static final long m_bBombTicking = 0x3001; // int
		public static final long m_nBombSite = 0x3004; // int
		public static final long m_flC4Blow = 0x3010; // float
		public static final long m_flTimerLength = 0x3014; // float
		public static final long m_flDefuseLength = 0x3024; // float
		public static final long m_flDefuseCountDown = 0x3028; // float
		public static final long m_bBombDefused = 0x302c; // int
		public static final long m_hBombDefuser = 0x3030; // int
	}

	public static class CCSTeam { // DT_CSTeam
	}

	public static class CCSPlayerResource { // DT_CSPlayerResource
		public static final long m_iPlayerC4 = 0x1cf4; // int
		public static final long m_iPlayerVIP = 0x1cf8; // int
		public static final long m_bHostageAlive = 0x1d14; // int[11] / m_bHostageAlive
		public static final long m_isHostageFollowingSomeone = 0x1d20; // int[11] / m_isHostageFollowingSomeone
		public static final long m_iHostageEntityIDs = 0x1d2c; // int[11] / m_iHostageEntityIDs
		public static final long m_bombsiteCenterA = 0x1cfc; // Vector
		public static final long m_bombsiteCenterB = 0x1d08; // Vector
		public static final long m_hostageRescueX = 0x1d5c; // int[3] / m_hostageRescueX
		public static final long m_hostageRescueY = 0x1d6c; // int[3] / m_hostageRescueY
		public static final long m_hostageRescueZ = 0x1d7c; // int[3] / m_hostageRescueZ
		public static final long m_iMVPs = 0x1d8c; // int[64] / m_iMVPs
		public static final long m_iArmor = 0x1f14; // int[64] / m_iArmor
		public static final long m_bHasHelmet = 0x1ed1; // int[64] / m_bHasHelmet
		public static final long m_bHasDefuser = 0x1e90; // int[64] / m_bHasDefuser
		public static final long m_iScore = 0x2018; // int[64] / m_iScore
		public static final long m_iCompetitiveRanking = 0x211c; // int[64] / m_iCompetitiveRanking
		public static final long m_iCompetitiveWins = 0x2220; // int[64] / m_iCompetitiveWins
		public static final long m_iCompetitiveRankType = 0x2324; // int[64] / m_iCompetitiveRankType
		public static final long m_iCompTeammateColor = 0x2368; // int[64] / m_iCompTeammateColor
		public static final long m_bControllingBot = 0x246c; // int[64] / m_bControllingBot
		public static final long m_iControlledPlayer = 0x24b0; // int[64] / m_iControlledPlayer
		public static final long m_iControlledByPlayer = 0x25b4; // int[64] / m_iControlledByPlayer
		public static final long m_iBotDifficulty = 0x4738; // int[64] / m_iBotDifficulty
		public static final long m_szClan = 0x483c; // const char *[64] / m_szClan
		public static final long m_iTotalCashSpent = 0x4c4c; // int[64] / m_iTotalCashSpent
		public static final long m_iGunGameLevel = 0x4d50; // int[64] / m_iGunGameLevel
		public static final long m_iCashSpentThisRound = 0x4e54; // int[64] / m_iCashSpentThisRound
		public static final long m_nEndMatchNextMapVotes = 0x55b4; // int[64] / m_nEndMatchNextMapVotes
		public static final long m_bEndMatchNextMapAllVoted = 0x56b8; // int
		public static final long m_nActiveCoinRank = 0x4f58; // int[64] / m_nActiveCoinRank
		public static final long m_nMusicID = 0x505c; // int[64] / m_nMusicID
		public static final long m_nPersonaDataPublicLevel = 0x5160; // int[64] / m_nPersonaDataPublicLevel
		public static final long m_nPersonaDataPublicCommendsLeader = 0x5264; // int[64] / m_nPersonaDataPublicCommendsLeader
		public static final long m_nPersonaDataPublicCommendsTeacher = 0x5368; // int[64] / m_nPersonaDataPublicCommendsTeacher
		public static final long m_nPersonaDataPublicCommendsFriendly = 0x546c; // int[64] / m_nPersonaDataPublicCommendsFriendly
	}

	public static class CCSPlayer { // DT_CSPlayer
		public static final long DT_CSLocalPlayerExclusive = 0x0; // int[11] / cslocaldata
		public static final long DT_CSNonLocalPlayerExclusive = 0x0; // float[1] / csnonlocaldata
		public static class DT_CSTeamExclusive { // m_EquippedLoadoutItemDefIndices
		}

		public static final long DT_CSTeamExclusive = 0x0; // DataTable[1] / csteamdata
		public static final long m_angEyeAngles_0 = 0xbb58; // float
		public static final long m_angEyeAngles_1 = 0xbb5c; // float
		public static final long m_iAddonBits = 0xab94; // int
		public static final long m_iPrimaryAddon = 0xab98; // int
		public static final long m_iSecondaryAddon = 0xab9c; // int
		public static final long m_iThrowGrenadeCounter = 0x4194; // int
		public static final long m_bWaitForNoAttack = 0x4198; // int
		public static final long m_bIsRespawningForDMBonus = 0x4199; // int
		public static final long m_iPlayerState = 0x415c; // int
		public static final long m_iAccount = 0xbb40; // int
		public static final long m_iStartAccount = 0xabc4; // int
		public static final long m_totalHitsOnServer = 0xabc8; // int
		public static final long m_bInBombZone = 0x4190; // int
		public static final long m_bInBuyZone = 0x4191; // int
		public static final long m_bInNoDefuseArea = 0x4192; // int
		public static final long m_bKilledByTaser = 0x41a9; // int
		public static final long m_iMoveState = 0x41ac; // int
		public static final long m_iClass = 0xbb50; // int
		public static final long m_ArmorValue = 0xbb54; // int
		public static final long m_angEyeAngles = 0xbb58; // Vector
		public static final long m_bHasDefuser = 0xbb64; // int
		public static final long m_bNightVisionOn = 0xabb9; // int
		public static final long m_bHasNightVision = 0xabba; // int
		public static final long m_bInHostageRescueZone = 0xbb65; // int
		public static final long m_bIsDefusing = 0x4160; // int
		public static final long m_bIsGrabbingHostage = 0x4161; // int
		public static final long m_bIsScoped = 0x4156; // int
		public static final long m_bIsWalking = 0x4157; // int
		public static final long m_bResumeZoom = 0x4158; // int
		public static final long m_fImmuneToGunGameDamageTime = 0x4164; // float
		public static final long m_bGunGameImmunity = 0x416c; // int
		public static final long m_bHasMovedSinceSpawn = 0x416d; // int
		public static final long m_bMadeFinalGunGameProgressiveKill = 0x416e; // int
		public static final long m_iGunGameProgressiveWeaponIndex = 0x4170; // int
		public static final long m_iNumGunGameTRKillPoints = 0x4174; // int
		public static final long m_iNumGunGameKillsWithCurrentWeapon = 0x4178; // int
		public static final long m_iNumRoundKills = 0x417c; // int
		public static final long m_fMolotovUseTime = 0x4188; // float
		public static final long m_fMolotovDamageTime = 0x418c; // float
		public static final long m_szArmsModel = 0x41b3; // const char *
		public static final long m_hCarriedHostage = 0xabd4; // int
		public static final long m_hCarriedHostageProp = 0xabd8; // int
		public static final long m_bIsRescuing = 0x4162; // int
		public static final long m_flGroundAccelLinearFracLastTime = 0xabc0; // float
		public static final long m_bCanMoveDuringFreezePeriod = 0x41b0; // int
		public static final long m_isCurrentGunGameLeader = 0x41b1; // int
		public static final long m_isCurrentGunGameTeamLeader = 0x41b2; // int
		public static final long m_flGuardianTooFarDistFrac = 0x419c; // float
		public static final long m_flDetectedByEnemySensorTime = 0x41a0; // float
		public static final long m_iMatchStats_Kills = 0xac3c; // int[29] / m_iMatchStats_Kills
		public static final long m_iMatchStats_Damage = 0xacb4; // int[29] / m_iMatchStats_Damage
		public static final long m_iMatchStats_EquipmentValue = 0xad2c; // int[29] / m_iMatchStats_EquipmentValue
		public static final long m_iMatchStats_MoneySaved = 0xada4; // int[29] / m_iMatchStats_MoneySaved
		public static final long m_iMatchStats_KillReward = 0xae1c; // int[29] / m_iMatchStats_KillReward
		public static final long m_iMatchStats_LiveTime = 0xae94; // int[29] / m_iMatchStats_LiveTime
		public static final long m_iMatchStats_Deaths = 0xaf0c; // int[29] / m_iMatchStats_Deaths
		public static final long m_iMatchStats_Assists = 0xaf84; // int[29] / m_iMatchStats_Assists
		public static final long m_iMatchStats_HeadShotKills = 0xaffc; // int[29] / m_iMatchStats_HeadShotKills
		public static final long m_iMatchStats_Objective = 0xb074; // int[29] / m_iMatchStats_Objective
		public static final long m_iMatchStats_CashEarned = 0xb0ec; // int[29] / m_iMatchStats_CashEarned
		public static final long m_iMatchStats_UtilityDamage = 0xb164; // int[29] / m_iMatchStats_UtilityDamage
		public static final long m_iMatchStats_EnemiesFlashed = 0xb1dc; // int[29] / m_iMatchStats_EnemiesFlashed
		public static final long m_rank = 0xbb18; // int[5] / m_rank
		public static final long m_unMusicID = 0xbb30; // int
		public static final long m_bHasHelmet = 0xbb48; // int
		public static final long m_bHasHeavyArmor = 0xbb49; // int
		public static final long m_nHeavyAssaultSuitCooldownRemaining = 0xbb4c; // int
		public static final long m_flFlashDuration = 0xabf8; // float
		public static final long m_flFlashMaxAlpha = 0xabf4; // float
		public static final long m_iProgressBarDuration = 0xaba0; // int
		public static final long m_flProgressBarStartTime = 0xaba4; // float
		public static final long m_hRagdoll = 0xabd0; // int
		public static final long m_cycleLatch = 0xbce8; // int
		public static final long m_unCurrentEquipmentValue = 0xbb10; // int
		public static final long m_unRoundStartEquipmentValue = 0xbb12; // int
		public static final long m_unFreezetimeEndEquipmentValue = 0xbb14; // int
		public static final long m_bIsControllingBot = 0xc21a; // int
		public static final long m_bHasControlledBotThisRound = 0xc228; // int
		public static final long m_bCanControlObservedBot = 0xc21b; // int
		public static final long m_iControlledBotEntIndex = 0xc21c; // int
		public static final long m_bIsAssassinationTarget = 0xc219; // int
		public static final long m_bHud_MiniScoreHidden = 0xbb86; // int
		public static final long m_bHud_RadarHidden = 0xbb87; // int
		public static final long m_nLastKillerIndex = 0xbb88; // int
		public static final long m_nLastConcurrentKilled = 0xbb8c; // int
		public static final long m_nDeathCamMusic = 0xbb90; // int
		public static final long m_bIsHoldingLookAtWeapon = 0xc17d; // int
		public static final long m_bIsLookingAtWeapon = 0xc17c; // int
		public static final long m_iNumRoundKillsHeadshots = 0x4180; // int
		public static final long m_unTotalRoundDamageDealt = 0x4184; // int
		public static final long m_flLowerBodyYawTarget = 0x42c0; // float
		public static final long m_bStrafing = 0x42c4; // int
		public static final long m_flThirdpersonRecoil = 0xc1c8; // float
	}

	public static class CCSRagdoll { // DT_CSRagdoll
		public static final long m_vecRagdollOrigin = 0x30a0; // Vector
		public static final long m_hPlayer = 0x3084; // int
		public static final long m_nModelIndex = 0x28c; // int
		public static final long m_nForceBone = 0x2c44; // int
		public static final long m_vecForce = 0x2c38; // Vector
		public static final long m_vecRagdollVelocity = 0x3094; // Vector
		public static final long m_iDeathPose = 0x30ac; // int
		public static final long m_iDeathFrame = 0x30b0; // int
		public static final long m_iTeamNum = 0x128; // int
		public static final long m_bClientSideAnimation = 0x2ec8; // int
		public static final long m_flDeathYaw = 0x30b4; // float
		public static final long m_flAbsYaw = 0x30b8; // float
	}

	public static class CTEPlayerAnimEvent { // DT_TEPlayerAnimEvent
		public static final long m_iEvent = 0x24; // int
		public static final long m_nData = 0x28; // int
	}

	public static class CHostage { // DT_CHostage
		public static final long m_isRescued = 0x3668; // int
		public static final long m_jumpedThisFrame = 0x3669; // int
		public static final long m_iHealth = 0x134; // int
		public static final long m_iMaxHealth = 0x364c; // int
		public static final long m_lifeState = 0x293; // int
		public static final long m_fFlags = 0x138; // int
		public static final long m_nHostageState = 0x366c; // int
		public static final long m_flRescueStartTime = 0x3670; // float
		public static final long m_flGrabSuccessTime = 0x3674; // float
		public static final long m_flDropStartTime = 0x3678; // float
		public static final long m_vel = 0x365c; // Vector
		public static final long m_leader = 0x3658; // int
	}

	public static class CHostageCarriableProp { // DT_HostageCarriableProp
	}

	public static class CBaseCSGrenadeProjectile { // DT_BaseCSGrenadeProjectile
		public static final long m_vInitialVelocity = 0x3030; // Vector
		public static final long m_nBounces = 0x303c; // int
	}

	public static class CPredictedViewModel { // DT_PredictedViewModel
	}

	public static class CBaseTeamObjectiveResource { // DT_BaseTeamObjectiveResource
		public static final long m_iStopWatchTimer = 0xf6c; // int
		public static final long m_iNumControlPoints = 0xf70; // int
		public static final long m_bPlayingMiniRounds = 0xf78; // int
		public static final long m_bControlPointsReset = 0xf79; // int
		public static final long m_iUpdateCapHudParity = 0xf7c; // int
		public static final long m_vCPPositions_0 = 0xf84; // Vector
		public static final long m_vCPPositions = 0x0; // array elements: 8
		public static final long m_bCPIsVisible = 0xfe4; // int[7] / m_bCPIsVisible
		public static final long m_flLazyCapPerc = 0xfec; // float[7] / m_flLazyCapPerc
		public static final long m_iTeamIcons = 0x102c; // int[63] / m_iTeamIcons
		public static final long m_iTeamOverlays = 0x112c; // int[63] / m_iTeamOverlays
		public static final long m_iTeamReqCappers = 0x122c; // int[63] / m_iTeamReqCappers
		public static final long m_flTeamCapTime = 0x132c; // float[63] / m_flTeamCapTime
		public static final long m_iPreviousPoints = 0x142c; // int[191] / m_iPreviousPoints
		public static final long m_bTeamCanCap = 0x172c; // int[63] / m_bTeamCanCap
		public static final long m_iTeamBaseIcons = 0x176c; // int[31] / m_iTeamBaseIcons
		public static final long m_iBaseControlPoints = 0x17ec; // int[31] / m_iBaseControlPoints
		public static final long m_bInMiniRound = 0x186c; // int[7] / m_bInMiniRound
		public static final long m_iWarnOnCap = 0x1874; // int[7] / m_iWarnOnCap
		public static final long m_iszWarnSound_0 = 0x1894; // const char *
		public static final long m_iszWarnSound = 0x0; // array elements: 8
		public static final long m_flPathDistance = 0x208c; // float[7] / m_flPathDistance
		public static final long m_iNumTeamMembers = 0x20ac; // int[63] / m_iNumTeamMembers
		public static final long m_iCappingTeam = 0x21ac; // int[7] / m_iCappingTeam
		public static final long m_iTeamInZone = 0x21cc; // int[7] / m_iTeamInZone
		public static final long m_bBlocked = 0x21ec; // int[7] / m_bBlocked
		public static final long m_iOwner = 0x21f4; // int[7] / m_iOwner
		public static final long m_pszCapLayoutInHUD = 0x227c; // const char *
	}

	public static class CEconWearable { // DT_WearableItem
	}

	public static class CBaseAttributableItem { // DT_BaseAttributableItem
		public static class DT_AttributeContainer { // DT_ScriptCreatedItem
			public static final long m_iEntityLevel = 0x288; // int
			public static final long m_iItemIDHigh = 0x298; // int
			public static final long m_iItemIDLow = 0x29c; // int
			public static final long m_iAccountID = 0x2a0; // int
			public static final long m_iEntityQuality = 0x284; // int
			public static final long m_bInitialized = 0x2b0; // int
			public static final long m_szCustomName = 0x358; // const char *
			public static class DT_AttributeList { // _ST_m_Attributes_32
			}

			public static final long DT_AttributeList = 0x328; // DataTable[0] / m_NetworkedDynamicAttributesForDemos
		}

		public static final long DT_AttributeContainer = 0x34c0; // DataTable[3] / m_AttributeManager
		public static final long m_OriginalOwnerXuidLow = 0x3a00; // int
		public static final long m_OriginalOwnerXuidHigh = 0x3a04; // int
		public static final long m_nFallbackPaintKit = 0x3a08; // int
		public static final long m_nFallbackSeed = 0x3a0c; // int
		public static final long m_flFallbackWear = 0x3a10; // float
		public static final long m_nFallbackStatTrak = 0x3a14; // int
	}

	public static class CEconEntity { // DT_EconEntity
		public static class DT_AttributeContainer { // DT_ScriptCreatedItem
			public static final long m_iEntityLevel = 0x288; // int
			public static final long m_iItemIDHigh = 0x298; // int
			public static final long m_iItemIDLow = 0x29c; // int
			public static final long m_iAccountID = 0x2a0; // int
			public static final long m_iEntityQuality = 0x284; // int
			public static final long m_bInitialized = 0x2b0; // int
			public static final long m_szCustomName = 0x358; // const char *
			public static class DT_AttributeList { // _ST_m_Attributes_32
			}

			public static final long DT_AttributeList = 0x328; // DataTable[0] / m_NetworkedDynamicAttributesForDemos
		}

		public static final long DT_AttributeContainer = 0x34c0; // DataTable[3] / m_AttributeManager
		public static final long m_OriginalOwnerXuidLow = 0x3a00; // int
		public static final long m_OriginalOwnerXuidHigh = 0x3a04; // int
		public static final long m_nFallbackPaintKit = 0x3a08; // int
		public static final long m_nFallbackSeed = 0x3a0c; // int
		public static final long m_flFallbackWear = 0x3a10; // float
		public static final long m_nFallbackStatTrak = 0x3a14; // int
	}

	public static class NextBotCombatCharacter { // DT_NextBot
	}

	public static class CTestTraceline { // DT_TestTraceline
		public static final long m_vecOrigin = 0x16c; // Vector
		public static final long m_angRotation_0 = 0x160; // float
		public static final long m_angRotation_1 = 0x164; // float
		public static final long m_angRotation_2 = 0x168; // float
		public static final long moveparent = 0x17c; // int
	}

	public static class CTEWorldDecal { // DT_TEWorldDecal
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_nIndex = 0x2c; // int
	}

	public static class CTESpriteSpray { // DT_TESpriteSpray
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_vecDirection = 0x2c; // Vector
		public static final long m_nModelIndex = 0x38; // int
		public static final long m_fNoise = 0x40; // float
		public static final long m_nCount = 0x44; // int
		public static final long m_nSpeed = 0x3c; // int
	}

	public static class CTESprite { // DT_TESprite
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_nModelIndex = 0x2c; // int
		public static final long m_fScale = 0x30; // float
		public static final long m_nBrightness = 0x34; // int
	}

	public static class CTESparks { // DT_TESparks
		public static final long m_nMagnitude = 0x2c; // int
		public static final long m_nTrailLength = 0x30; // int
		public static final long m_vecDir = 0x34; // Vector
	}

	public static class CTESmoke { // DT_TESmoke
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_nModelIndex = 0x2c; // int
		public static final long m_fScale = 0x30; // float
		public static final long m_nFrameRate = 0x34; // int
	}

	public static class CTEShowLine { // DT_TEShowLine
		public static final long m_vecEnd = 0x2c; // Vector
	}

	public static class CTEProjectedDecal { // DT_TEProjectedDecal
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_angRotation = 0x2c; // Vector
		public static final long m_flDistance = 0x38; // float
		public static final long m_nIndex = 0x3c; // int
	}

	public static class CFEPlayerDecal { // DT_FEPlayerDecal
		public static final long m_nUniqueID = 0xf68; // int
		public static final long m_unAccountID = 0xf6c; // int
		public static final long m_unTraceID = 0xf70; // int
		public static final long m_rtGcTime = 0xf74; // int
		public static final long m_vecEndPos = 0xf78; // Vector
		public static final long m_vecStart = 0xf84; // Vector
		public static final long m_vecRight = 0xf90; // Vector
		public static final long m_vecNormal = 0xf9c; // Vector
		public static final long m_nEntity = 0xfac; // int
		public static final long m_nPlayer = 0xfa8; // int
		public static final long m_nHitbox = 0xfb0; // int
		public static final long m_nTintID = 0xfb4; // int
		public static final long m_flCreationTime = 0xfb8; // float
		public static final long m_nVersion = 0xfbc; // int
		public static final long m_ubSignature = 0xfbd; // int[127] / m_ubSignature
	}

	public static class CTEPlayerDecal { // DT_TEPlayerDecal
		public static final long m_vecOrigin = 0x24; // Vector
		public static final long m_vecStart = 0x30; // Vector
		public static final long m_vecRight = 0x3c; // Vector
		public static final long m_nEntity = 0x48; // int
		public static final long m_nPlayer = 0x20; // int
		public static final long m_nHitbox = 0x4c; // int
	}

	public static class CTEPhysicsProp { // DT_TEPhysicsProp
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_angRotation_0 = 0x2c; // float
		public static final long m_angRotation_1 = 0x30; // float
		public static final long m_angRotation_2 = 0x34; // float
		public static final long m_vecVelocity = 0x38; // Vector
		public static final long m_nModelIndex = 0x44; // int
		public static final long m_nFlags = 0x4c; // int
		public static final long m_nSkin = 0x48; // int
		public static final long m_nEffects = 0x50; // int
		public static final long m_clrRender = 0x54; // int
	}

	public static class CTEParticleSystem { // DT_TEParticleSystem
		public static final long m_vecOrigin_0 = 0x20; // float
		public static final long m_vecOrigin_1 = 0x24; // float
		public static final long m_vecOrigin_2 = 0x28; // float
	}

	public static class CTEMuzzleFlash { // DT_TEMuzzleFlash
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_vecAngles = 0x2c; // Vector
		public static final long m_flScale = 0x38; // float
		public static final long m_nType = 0x3c; // int
	}

	public static class CTELargeFunnel { // DT_TELargeFunnel
		public static final long m_nModelIndex = 0x2c; // int
		public static final long m_nReversed = 0x30; // int
	}

	public static class CTEKillPlayerAttachments { // DT_TEKillPlayerAttachments
		public static final long m_nPlayer = 0x20; // int
	}

	public static class CTEImpact { // DT_TEImpact
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_vecNormal = 0x2c; // Vector
		public static final long m_iType = 0x38; // int
		public static final long m_ucFlags = 0x3c; // int
	}

	public static class CTEGlowSprite { // DT_TEGlowSprite
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_nModelIndex = 0x2c; // int
		public static final long m_fScale = 0x30; // float
		public static final long m_fLife = 0x34; // float
		public static final long m_nBrightness = 0x38; // int
	}

	public static class CTEShatterSurface { // DT_TEShatterSurface
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_vecAngles = 0x2c; // Vector
		public static final long m_vecForce = 0x38; // Vector
		public static final long m_vecForcePos = 0x44; // Vector
		public static final long m_flWidth = 0x50; // float
		public static final long m_flHeight = 0x54; // float
		public static final long m_flShardSize = 0x58; // float
		public static final long m_nSurfaceType = 0x68; // int
		public static final long m_uchFrontColor_0 = 0x6c; // int
		public static final long m_uchFrontColor_1 = 0x6d; // int
		public static final long m_uchFrontColor_2 = 0x6e; // int
		public static final long m_uchBackColor_0 = 0x6f; // int
		public static final long m_uchBackColor_1 = 0x70; // int
		public static final long m_uchBackColor_2 = 0x71; // int
	}

	public static class CTEFootprintDecal { // DT_TEFootprintDecal
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_vecDirection = 0x2c; // Vector
		public static final long m_nEntity = 0x44; // int
		public static final long m_nIndex = 0x48; // int
		public static final long m_chMaterialType = 0x4c; // int
	}

	public static class CTEFizz { // DT_TEFizz
		public static final long m_nEntity = 0x20; // int
		public static final long m_nModelIndex = 0x24; // int
		public static final long m_nDensity = 0x28; // int
		public static final long m_nCurrent = 0x2c; // int
	}

	public static class CTEExplosion { // DT_TEExplosion
		public static final long m_nModelIndex = 0x2c; // int
		public static final long m_fScale = 0x30; // float
		public static final long m_nFrameRate = 0x34; // int
		public static final long m_nFlags = 0x38; // int
		public static final long m_vecNormal = 0x3c; // Vector
		public static final long m_chMaterialType = 0x48; // int
		public static final long m_nRadius = 0x4c; // int
		public static final long m_nMagnitude = 0x50; // int
	}

	public static class CTEEnergySplash { // DT_TEEnergySplash
		public static final long m_vecDir = 0x2c; // Vector
		public static final long m_bExplosive = 0x38; // int
	}

	public static class CTEEffectDispatch { // DT_TEEffectDispatch
		public static final long DT_EffectData = 0x20; // int[21] / m_EffectData
	}

	public static class CTEDynamicLight { // DT_TEDynamicLight
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long r = 0x30; // int
		public static final long g = 0x34; // int
		public static final long b = 0x38; // int
		public static final long exponent = 0x3c; // int
		public static final long m_fRadius = 0x2c; // float
		public static final long m_fTime = 0x40; // float
		public static final long m_fDecay = 0x44; // float
	}

	public static class CTEDecal { // DT_TEDecal
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_vecStart = 0x2c; // Vector
		public static final long m_nEntity = 0x38; // int
		public static final long m_nHitbox = 0x3c; // int
		public static final long m_nIndex = 0x40; // int
	}

	public static class CTEClientProjectile { // DT_TEClientProjectile
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_vecVelocity = 0x2c; // Vector
		public static final long m_nModelIndex = 0x38; // int
		public static final long m_nLifeTime = 0x3c; // int
		public static final long m_hOwner = 0x40; // int
	}

	public static class CTEBubbleTrail { // DT_TEBubbleTrail
		public static final long m_vecMins = 0x20; // Vector
		public static final long m_vecMaxs = 0x2c; // Vector
		public static final long m_nModelIndex = 0x3c; // int
		public static final long m_flWaterZ = 0x38; // float
		public static final long m_nCount = 0x40; // int
		public static final long m_fSpeed = 0x44; // float
	}

	public static class CTEBubbles { // DT_TEBubbles
		public static final long m_vecMins = 0x20; // Vector
		public static final long m_vecMaxs = 0x2c; // Vector
		public static final long m_nModelIndex = 0x3c; // int
		public static final long m_fHeight = 0x38; // float
		public static final long m_nCount = 0x40; // int
		public static final long m_fSpeed = 0x44; // float
	}

	public static class CTEBSPDecal { // DT_TEBSPDecal
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_nEntity = 0x2c; // int
		public static final long m_nIndex = 0x30; // int
	}

	public static class CTEBreakModel { // DT_TEBreakModel
		public static final long m_vecOrigin = 0x20; // Vector
		public static final long m_angRotation_0 = 0x2c; // float
		public static final long m_angRotation_1 = 0x30; // float
		public static final long m_angRotation_2 = 0x34; // float
		public static final long m_vecSize = 0x38; // Vector
		public static final long m_vecVelocity = 0x44; // Vector
		public static final long m_nModelIndex = 0x54; // int
		public static final long m_nRandomization = 0x50; // int
		public static final long m_nCount = 0x58; // int
		public static final long m_fTime = 0x5c; // float
		public static final long m_nFlags = 0x60; // int
	}

	public static class CTEBloodStream { // DT_TEBloodStream
		public static final long m_vecDirection = 0x2c; // Vector
		public static final long r = 0x38; // int
		public static final long g = 0x3c; // int
		public static final long b = 0x40; // int
		public static final long a = 0x44; // int
		public static final long m_nAmount = 0x48; // int
	}

	public static class CTEBloodSprite { // DT_TEBloodSprite
		public static final long m_vecDirection = 0x2c; // Vector
		public static final long r = 0x38; // int
		public static final long g = 0x3c; // int
		public static final long b = 0x40; // int
		public static final long a = 0x44; // int
		public static final long m_nSprayModel = 0x4c; // int
		public static final long m_nDropModel = 0x48; // int
		public static final long m_nSize = 0x50; // int
	}

	public static class CTEBeamSpline { // DT_TEBeamSpline
		public static final long m_vecPoints_0 = 0x20; // Vector
		public static final long m_vecPoints = 0x0; // array elements: 16
	}

	public static class CTEBeamRingPoint { // DT_TEBeamRingPoint
		public static final long m_vecCenter = 0x5c; // Vector
		public static final long m_flStartRadius = 0x68; // float
		public static final long m_flEndRadius = 0x6c; // float
	}

	public static class CTEBeamRing { // DT_TEBeamRing
		public static final long m_nStartEntity = 0x5c; // int
		public static final long m_nEndEntity = 0x60; // int
	}

	public static class CTEBeamPoints { // DT_TEBeamPoints
		public static final long m_vecStartPoint = 0x5c; // Vector
		public static final long m_vecEndPoint = 0x68; // Vector
	}

	public static class CTEBeamLaser { // DT_TEBeamLaser
		public static final long m_nStartEntity = 0x5c; // int
		public static final long m_nEndEntity = 0x60; // int
	}

	public static class CTEBeamFollow { // DT_TEBeamFollow
		public static final long m_iEntIndex = 0x5c; // int
	}

	public static class CTEBeamEnts { // DT_TEBeamEnts
		public static final long m_nStartEntity = 0x5c; // int
		public static final long m_nEndEntity = 0x60; // int
	}

	public static class CTEBeamEntPoint { // DT_TEBeamEntPoint
		public static final long m_nStartEntity = 0x5c; // int
		public static final long m_nEndEntity = 0x60; // int
		public static final long m_vecStartPoint = 0x64; // Vector
		public static final long m_vecEndPoint = 0x70; // Vector
	}

	public static class CTEBaseBeam { // DT_BaseBeam
		public static final long m_nHaloIndex = 0x24; // int
		public static final long m_nStartFrame = 0x28; // int
		public static final long m_nFrameRate = 0x2c; // int
		public static final long m_fLife = 0x30; // float
		public static final long m_fWidth = 0x34; // float
		public static final long m_fEndWidth = 0x38; // float
		public static final long m_nFadeLength = 0x3c; // int
		public static final long m_fAmplitude = 0x40; // float
		public static final long m_nSpeed = 0x54; // int
		public static final long r = 0x44; // int
		public static final long g = 0x48; // int
		public static final long b = 0x4c; // int
		public static final long a = 0x50; // int
		public static final long m_nFlags = 0x58; // int
	}

	public static class CTEArmorRicochet { // DT_TEArmorRicochet
	}

	public static class CTEMetalSparks { // DT_TEMetalSparks
		public static final long m_vecDir = 0x2c; // Vector
	}

	public static class CSteamJet { // DT_SteamJet
		public static final long m_SpreadSpeed = 0x10a0; // float
		public static final long m_Speed = 0x10a4; // float
		public static final long m_StartSize = 0x10a8; // float
		public static final long m_EndSize = 0x10ac; // float
		public static final long m_Rate = 0x10b0; // float
		public static final long m_JetLength = 0x10b4; // float
		public static final long m_bEmit = 0x10b8; // int
		public static final long m_bFaceLeft = 0x10c0; // int
		public static final long m_nType = 0x10bc; // int
		public static final long m_spawnflags = 0x10c4; // int
		public static final long m_flRollSpeed = 0x10c8; // float
	}

	public static class CSmokeStack { // DT_SmokeStack
		public static final long m_SpreadSpeed = 0x10f8; // float
		public static final long m_Speed = 0x10fc; // float
		public static final long m_StartSize = 0x1100; // float
		public static final long m_EndSize = 0x1104; // float
		public static final long m_Rate = 0x1108; // float
		public static final long m_JetLength = 0x110c; // float
		public static final long m_bEmit = 0x1110; // int
		public static final long m_flBaseSpread = 0x1114; // float
		public static final long m_flTwist = 0x1168; // float
		public static final long m_flRollSpeed = 0x11b0; // float
		public static final long m_iMaterialModel = 0x116c; // int
		public static final long m_AmbientLight_m_vPos = 0x1118; // Vector
		public static final long m_AmbientLight_m_vColor = 0x1124; // Vector
		public static final long m_AmbientLight_m_flIntensity = 0x1130; // float
		public static final long m_DirLight_m_vPos = 0x1134; // Vector
		public static final long m_DirLight_m_vColor = 0x1140; // Vector
		public static final long m_DirLight_m_flIntensity = 0x114c; // float
		public static final long m_vWind = 0x115c; // Vector
	}

	public static class DustTrail { // DT_DustTrail
		public static final long m_SpawnRate = 0x10a0; // float
		public static final long m_Color = 0x10a4; // Vector
		public static final long m_ParticleLifetime = 0x10b4; // float
		public static final long m_StopEmitTime = 0x10bc; // float
		public static final long m_MinSpeed = 0x10c0; // float
		public static final long m_MaxSpeed = 0x10c4; // float
		public static final long m_MinDirectedSpeed = 0x10c8; // float
		public static final long m_MaxDirectedSpeed = 0x10cc; // float
		public static final long m_StartSize = 0x10d0; // float
		public static final long m_EndSize = 0x10d4; // float
		public static final long m_SpawnRadius = 0x10d8; // float
		public static final long m_bEmit = 0x10e8; // int
		public static final long m_Opacity = 0x10b0; // float
	}

	public static class CFireTrail { // DT_FireTrail
		public static final long m_nAttachment = 0x10a0; // int
		public static final long m_flLifetime = 0x10a4; // float
	}

	public static class SporeTrail { // DT_SporeTrail
		public static final long m_flSpawnRate = 0x10a4; // float
		public static final long m_vecEndColor = 0x1098; // Vector
		public static final long m_flParticleLifetime = 0x10a8; // float
		public static final long m_flStartSize = 0x10ac; // float
		public static final long m_flEndSize = 0x10b0; // float
		public static final long m_flSpawnRadius = 0x10b4; // float
		public static final long m_bEmit = 0x10c4; // int
	}

	public static class SporeExplosion { // DT_SporeExplosion
		public static final long m_flSpawnRate = 0x10a0; // float
		public static final long m_flParticleLifetime = 0x10a4; // float
		public static final long m_flStartSize = 0x10a8; // float
		public static final long m_flEndSize = 0x10ac; // float
		public static final long m_flSpawnRadius = 0x10b0; // float
		public static final long m_bEmit = 0x10b8; // int
		public static final long m_bDontRemove = 0x10b9; // int
	}

	public static class RocketTrail { // DT_RocketTrail
		public static final long m_SpawnRate = 0x10a0; // float
		public static final long m_StartColor = 0x10a4; // Vector
		public static final long m_EndColor = 0x10b0; // Vector
		public static final long m_ParticleLifetime = 0x10c0; // float
		public static final long m_StopEmitTime = 0x10c4; // float
		public static final long m_MinSpeed = 0x10c8; // float
		public static final long m_MaxSpeed = 0x10cc; // float
		public static final long m_StartSize = 0x10d0; // float
		public static final long m_EndSize = 0x10d4; // float
		public static final long m_SpawnRadius = 0x10d8; // float
		public static final long m_bEmit = 0x10e8; // int
		public static final long m_nAttachment = 0x10ec; // int
		public static final long m_Opacity = 0x10bc; // float
		public static final long m_bDamaged = 0x10e9; // int
		public static final long m_flFlareScale = 0x10fc; // float
	}

	public static class SmokeTrail { // DT_SmokeTrail
		public static final long m_SpawnRate = 0x10a0; // float
		public static final long m_StartColor = 0x10a4; // Vector
		public static final long m_EndColor = 0x10b0; // Vector
		public static final long m_ParticleLifetime = 0x10c0; // float
		public static final long m_StopEmitTime = 0x10c4; // float
		public static final long m_MinSpeed = 0x10c8; // float
		public static final long m_MaxSpeed = 0x10cc; // float
		public static final long m_MinDirectedSpeed = 0x10d0; // float
		public static final long m_MaxDirectedSpeed = 0x10d4; // float
		public static final long m_StartSize = 0x10d8; // float
		public static final long m_EndSize = 0x10dc; // float
		public static final long m_SpawnRadius = 0x10e0; // float
		public static final long m_bEmit = 0x10f0; // int
		public static final long m_nAttachment = 0x10f4; // int
		public static final long m_Opacity = 0x10bc; // float
	}

	public static class CPropVehicleDriveable { // DT_PropVehicleDriveable
		public static final long m_hPlayer = 0x3010; // int
		public static final long m_nSpeed = 0x3014; // int
		public static final long m_nRPM = 0x3018; // int
		public static final long m_flThrottle = 0x301c; // float
		public static final long m_nBoostTimeLeft = 0x3020; // int
		public static final long m_nHasBoost = 0x3024; // int
		public static final long m_nScannerDisabledWeapons = 0x3028; // int
		public static final long m_nScannerDisabledVehicle = 0x302c; // int
		public static final long m_bEnterAnimOn = 0x304c; // int
		public static final long m_bExitAnimOn = 0x304d; // int
		public static final long m_bUnableToFire = 0x30b5; // int
		public static final long m_vecEyeExitEndpoint = 0x30a8; // Vector
		public static final long m_bHasGun = 0x30b4; // int
		public static final long m_vecGunCrosshair = 0x3054; // Vector
	}

	public static class ParticleSmokeGrenade { // DT_ParticleSmokeGrenade
		public static final long m_flSpawnTime = 0x10b0; // float
		public static final long m_FadeStartTime = 0x10b4; // float
		public static final long m_FadeEndTime = 0x10b8; // float
		public static final long m_MinColor = 0x10c0; // Vector
		public static final long m_MaxColor = 0x10cc; // Vector
		public static final long m_CurrentStage = 0x10a0; // int
	}

	public static class CParticleFire { // DT_ParticleFire
		public static final long m_vDirection = 0x10bc; // Vector
	}

	public static class MovieExplosion { // DT_MovieExplosion
	}

	public static class CTEGaussExplosion { // DT_TEGaussExplosion
		public static final long m_nType = 0x2c; // int
		public static final long m_vecDirection = 0x30; // Vector
	}

	public static class CEnvQuadraticBeam { // DT_QuadraticBeam
		public static final long m_targetPosition = 0xf68; // Vector
		public static final long m_controlPosition = 0xf74; // Vector
		public static final long m_scrollRate = 0xf80; // float
		public static final long m_flWidth = 0xf84; // float
	}

	public static class CEmbers { // DT_Embers
		public static final long m_nDensity = 0xf68; // int
		public static final long m_nLifetime = 0xf6c; // int
		public static final long m_nSpeed = 0xf70; // int
		public static final long m_bEmit = 0xf74; // int
	}

	public static class CEnvWind { // DT_EnvWind
		public static final long DT_EnvWindShared = 0xf68; // float[11] / m_EnvWindShared
	}

	public static class CPrecipitation { // DT_Precipitation
		public static final long m_nPrecipType = 0xf94; // int
	}

	public static class CPrecipitationBlocker { // DT_PrecipitationBlocker
	}

	public static class CVoteController { // DT_VoteController
		public static final long m_iActiveIssueIndex = 0xf78; // int
		public static final long m_iOnlyTeamToVote = 0xf7c; // int
		public static final long m_nVoteOptionCount = 0xf80; // int[4] / m_nVoteOptionCount
		public static final long m_nPotentialVotes = 0xf98; // int
		public static final long m_bIsYesNoVote = 0xf9e; // int
	}

	public static class CHandleTest { // DT_HandleTest
		public static final long m_Handle = 0xf68; // int
		public static final long m_bSendHandle = 0xf6c; // int
	}

	public static class CTeamplayRoundBasedRulesProxy { // DT_TeamplayRoundBasedRulesProxy
		public static final long DT_TeamplayRoundBasedRules = 0x0; // int[12] / teamplayroundbased_gamerules_data
	}

	public static class CSpriteTrail { // DT_SpriteTrail
		public static final long m_flLifeTime = 0x1604; // float
		public static final long m_flStartWidth = 0x1608; // float
		public static final long m_flEndWidth = 0x160c; // float
		public static final long m_flStartWidthVariance = 0x1610; // float
		public static final long m_flTextureRes = 0x1614; // float
		public static final long m_flMinFadeLength = 0x1618; // float
		public static final long m_vecSkyboxOrigin = 0x161c; // Vector
		public static final long m_flSkyboxScale = 0x1628; // float
	}

	public static class CSpriteOriented { // DT_SpriteOriented
	}

	public static class CSprite { // DT_Sprite
		public static final long m_hAttachedToEntity = 0xf7c; // int
		public static final long m_nAttachment = 0xf80; // int
		public static final long m_flScaleTime = 0xf9c; // float
		public static final long m_flSpriteScale = 0xf98; // float
		public static final long m_flSpriteFramerate = 0xf84; // float
		public static final long m_flGlowProxySize = 0xfa4; // float
		public static final long m_flHDRColorScale = 0xfa8; // float
		public static final long m_flFrame = 0xf88; // float
		public static final long m_flBrightnessTime = 0xf94; // float
		public static final long m_nBrightness = 0xf90; // int
		public static final long m_bWorldSpaceScale = 0xfa0; // int
	}

	public static class CRagdollPropAttached { // DT_Ragdoll_Attached
		public static final long m_boneIndexAttached = 0x3378; // int
		public static final long m_ragdollAttachedObjectIndex = 0x3374; // int
		public static final long m_attachmentPointBoneSpace = 0x3350; // Vector
		public static final long m_attachmentPointRagdollSpace = 0x3368; // Vector
	}

	public static class CRagdollProp { // DT_Ragdoll
		public static final long m_ragAngles_0 = 0x3124; // Vector
		public static final long m_ragAngles = 0x0; // array elements: 24
		public static final long m_ragPos_0 = 0x3004; // Vector
		public static final long m_ragPos = 0x0; // array elements: 24
		public static final long m_hUnragdoll = 0x333c; // int
		public static final long m_flBlendWeight = 0x3340; // float
		public static final long m_nOverlaySequence = 0x3348; // int
	}

	public static class CPoseController { // DT_PoseController
		public static final long m_hProps = 0xf68; // int[3] / m_hProps
		public static final long m_chPoseIndex = 0xf78; // int[3] / m_chPoseIndex
		public static final long m_bPoseValueParity = 0xf7c; // int
		public static final long m_fPoseValue = 0xf80; // float
		public static final long m_fInterpolationTime = 0xf84; // float
		public static final long m_bInterpolationWrap = 0xf88; // int
		public static final long m_fCycleFrequency = 0xf8c; // float
		public static final long m_nFModType = 0xf90; // int
		public static final long m_fFModTimeOffset = 0xf94; // float
		public static final long m_fFModRate = 0xf98; // float
		public static final long m_fFModAmplitude = 0xf9c; // float
	}

	public static class CInfoLadderDismount { // DT_InfoLadderDismount
	}

	public static class CFuncLadder { // DT_FuncLadder
		public static final long m_vecPlayerMountPositionTop = 0xf98; // Vector
		public static final long m_vecPlayerMountPositionBottom = 0xfa4; // Vector
		public static final long m_vecLadderDir = 0xf68; // Vector
		public static final long m_bFakeLadder = 0xfb1; // int
	}

	public static class CTEFoundryHelpers { // DT_TEFoundryHelpers
		public static final long m_iEntity = 0x20; // int
	}

	public static class CEnvDetailController { // DT_DetailController
		public static final long m_flFadeEndDist = 0xf6c; // float
	}

	public static class CWorld { // DT_World
		public static final long m_flWaveHeight = 0xf68; // float
		public static final long m_WorldMins = 0xf6c; // Vector
		public static final long m_WorldMaxs = 0xf78; // Vector
		public static final long m_bStartDark = 0xf84; // int
		public static final long m_flMaxOccludeeArea = 0xf88; // float
		public static final long m_flMinOccluderArea = 0xf8c; // float
		public static final long m_flMaxPropScreenSpaceWidth = 0xf94; // float
		public static final long m_flMinPropScreenSpaceWidth = 0xf90; // float
		public static final long m_iszDetailSpriteMaterial = 0xfa0; // const char *
		public static final long m_bColdWorld = 0xf98; // int
		public static final long m_iTimeOfDay = 0xf9c; // int
	}

	public static class CWaterLODControl { // DT_WaterLODControl
		public static final long m_flCheapWaterStartDistance = 0xf68; // float
		public static final long m_flCheapWaterEndDistance = 0xf6c; // float
	}

	public static class CWaterBullet { // DT_WaterBullet
	}

	public static class CWorldVguiText { // DT_WorldVguiText
		public static final long m_bEnabled = 0xf65; // int
		public static final long m_szDisplayText = 0xf66; // const char *
		public static final long m_szDisplayTextOption = 0x1166; // const char *
		public static final long m_szFont = 0x1266; // const char *
		public static final long m_iTextPanelWidth = 0x12ac; // int
		public static final long m_clrText = 0x12a6; // int
	}

	public static class CVGuiScreen { // DT_VGuiScreen
		public static final long m_flWidth = 0xf70; // float
		public static final long m_flHeight = 0xf74; // float
		public static final long m_fScreenFlags = 0xf9c; // int
		public static final long m_nPanelName = 0xf78; // int
		public static final long m_nAttachmentIndex = 0xf94; // int
		public static final long m_nOverlayMaterial = 0xf98; // int
		public static final long m_hPlayerOwner = 0x1008; // int
	}

	public static class CPropJeep { // DT_PropJeep
		public static final long m_bHeadlightIsOn = 0x3180; // int
	}

	public static class CPropVehicleChoreoGeneric { // DT_PropVehicleChoreoGeneric
		public static final long m_hPlayer = 0x3070; // int
		public static final long m_bEnterAnimOn = 0x3078; // int
		public static final long m_bExitAnimOn = 0x3079; // int
		public static final long m_bForceEyesToAttachment = 0x3088; // int
		public static final long m_vecEyeExitEndpoint = 0x307c; // Vector
		public static final long m_vehicleView_bClampEyeAngles = 0x3118; // int
		public static final long m_vehicleView_flPitchCurveZero = 0x311c; // float
		public static final long m_vehicleView_flPitchCurveLinear = 0x3120; // float
		public static final long m_vehicleView_flRollCurveZero = 0x3124; // float
		public static final long m_vehicleView_flRollCurveLinear = 0x3128; // float
		public static final long m_vehicleView_flFOV = 0x312c; // float
		public static final long m_vehicleView_flYawMin = 0x3130; // float
		public static final long m_vehicleView_flYawMax = 0x3134; // float
		public static final long m_vehicleView_flPitchMin = 0x3138; // float
		public static final long m_vehicleView_flPitchMax = 0x313c; // float
	}

	public static class CTriggerSoundOperator { // DT_TriggerSoundOperator
		public static final long m_nSoundOperator = 0xf94; // int
	}

	public static class CBaseVPhysicsTrigger { // DT_BaseVPhysicsTrigger
	}

	public static class CTriggerPlayerMovement { // DT_TriggerPlayerMovement
	}

	public static class CBaseTrigger { // DT_BaseTrigger
		public static final long m_bClientSidePredicted = 0xf91; // int
		public static final long m_spawnflags = 0x314; // int
	}

	public static class CTest_ProxyToggle_Networkable { // DT_ProxyToggle
		public static final long DT_ProxyToggle_ProxiedData = 0x0; // int[0] / blah
	}

	public static class CTesla { // DT_Tesla
		public static final long m_SoundName = 0xf98; // const char *
		public static final long m_iszSpriteName = 0xfd8; // const char *
	}

	public static class CTeam { // DT_Team
		public static final long m_bSurrendered = 0x1108; // int
		public static final long m_scoreTotal = 0x10dc; // int
		public static final long m_scoreFirstHalf = 0x10e0; // int
		public static final long m_scoreSecondHalf = 0x10e4; // int
		public static final long m_scoreOvertime = 0x10e8; // int
		public static final long m_iClanID = 0x10f4; // int
		public static final long m_szTeamname = 0xf88; // const char *
		public static final long m_szClanTeamname = 0xfa8; // const char *
		public static final long m_szTeamFlagImage = 0xfc8; // const char *
		public static final long m_szTeamLogoImage = 0xfd0; // const char *
		public static final long m_szTeamMatchStat = 0xfd8; // const char *
		public static final long m_nGGLeaderEntIndex_CT = 0x10ec; // int
		public static final long m_nGGLeaderEntIndex_T = 0x10f0; // int
		public static final long m_numMapVictories = 0x110c; // int
		public static final long player_array_element = 0x0; // int
		public static final long  player_array  = 0x0; // array elements: 64
	}

	public static class CSunlightShadowControl { // DT_SunlightShadowControl
		public static final long m_shadowDirection = 0xf68; // Vector
		public static final long m_bEnabled = 0xf74; // int
		public static final long m_TextureName = 0xf75; // const char *
		public static final long m_LightColor = 0x1088; // int
		public static final long m_flColorTransitionTime = 0x109c; // float
		public static final long m_flSunDistance = 0x10a0; // float
		public static final long m_flFOV = 0x10a4; // float
		public static final long m_flNearZ = 0x10a8; // float
		public static final long m_flNorthOffset = 0x10ac; // float
		public static final long m_bEnableShadows = 0x10b0; // int
	}

	public static class CSun { // DT_Sun
		public static final long m_clrOverlay = 0x1108; // int
		public static final long m_vDirection = 0x1114; // Vector
		public static final long m_bOn = 0x1120; // int
		public static final long m_nSize = 0x110c; // int
		public static final long m_nOverlaySize = 0x1110; // int
		public static final long m_nMaterial = 0x1124; // int
		public static final long m_nOverlayMaterial = 0x1128; // int
		public static final long HDRColorScale = 0x0; // float
		public static final long glowDistanceScale = 0x0; // float
	}

	public static class CParticlePerformanceMonitor { // DT_ParticlePerformanceMonitor
		public static final long m_bMeasurePerf = 0xf66; // int
		public static final long m_bDisplayPerf = 0xf65; // int
	}

	public static class CSpotlightEnd { // DT_SpotlightEnd
		public static final long m_flLightScale = 0xf68; // float
		public static final long m_Radius = 0xf6c; // float
	}

	public static class CSpatialEntity { // DT_SpatialEntity
		public static final long m_vecOrigin = 0xf68; // Vector
		public static final long m_minFalloff = 0xf74; // float
		public static final long m_maxFalloff = 0xf78; // float
		public static final long m_flCurWeight = 0xf7c; // float
		public static final long m_bEnabled = 0x1084; // int
	}

	public static class CSlideshowDisplay { // DT_SlideshowDisplay
		public static final long m_bEnabled = 0xf65; // int
		public static final long m_szDisplayText = 0xf66; // const char *
		public static final long m_szSlideshowDirectory = 0xfe6; // const char *
		public static final long m_chCurrentSlideLists = 0x1088; // int[15] / m_chCurrentSlideLists
		public static final long m_fMinSlideTime = 0x10a0; // float
		public static final long m_fMaxSlideTime = 0x10a4; // float
		public static final long m_iCycleType = 0x10ac; // int
		public static final long m_bNoListRepeats = 0x10b0; // int
	}

	public static class CShadowControl { // DT_ShadowControl
		public static final long m_shadowDirection = 0xf68; // Vector
		public static final long m_shadowColor = 0xf74; // int
		public static final long m_flShadowMaxDist = 0xf78; // float
		public static final long m_bDisableShadows = 0xf7c; // int
		public static final long m_bEnableLocalLightShadows = 0xf7d; // int
	}

	public static class CSceneEntity { // DT_SceneEntity
		public static final long m_nSceneStringIndex = 0xf7c; // int
		public static final long m_bIsPlayingBack = 0xf70; // int
		public static final long m_bPaused = 0xf71; // int
		public static final long m_bMultiplayer = 0xf72; // int
		public static final long m_flForceClientTime = 0xf78; // float
		public static final long _ST_m_hActorList_16 = 0x0; // int[16] / m_hActorList
	}

	public static class CRopeKeyframe { // DT_RopeKeyframe
		public static final long m_iRopeMaterialModelIndex = 0xfa4; // int
		public static final long m_hStartPoint = 0x129c; // int
		public static final long m_hEndPoint = 0x12a0; // int
		public static final long m_iStartAttachment = 0x12a4; // int
		public static final long m_iEndAttachment = 0x12a6; // int
		public static final long m_fLockedPoints = 0x12b8; // int
		public static final long m_Slack = 0x12b0; // int
		public static final long m_RopeLength = 0x12ac; // int
		public static final long m_RopeFlags = 0xfa0; // int
		public static final long m_TextureScale = 0x12b4; // float
		public static final long m_nSegments = 0x1298; // int
		public static final long m_bConstrainBetweenEndpoints = 0x1350; // int
		public static final long m_Subdiv = 0x12a8; // int
		public static final long m_Width = 0x12c0; // float
		public static final long m_flScrollSpeed = 0xf9c; // float
		public static final long m_vecOrigin = 0x16c; // Vector
		public static final long moveparent = 0x17c; // int
		public static final long m_iParentAttachment = 0x340; // int
		public static final long m_iDefaultRopeMaterialModelIndex = 0xfa8; // int
		public static final long m_nMinCPULevel = 0xf18; // int
		public static final long m_nMaxCPULevel = 0xf19; // int
		public static final long m_nMinGPULevel = 0xf1a; // int
		public static final long m_nMaxGPULevel = 0xf1b; // int
	}

	public static class CRagdollManager { // DT_RagdollManager
	}

	public static class CPhysicsPropMultiplayer { // DT_PhysicsPropMultiplayer
		public static final long m_iPhysicsMode = 0x3040; // int
		public static final long m_fMass = 0x3044; // float
		public static final long m_collisionMins = 0x3048; // Vector
		public static final long m_collisionMaxs = 0x3054; // Vector
	}

	public static class CPhysBoxMultiplayer { // DT_PhysBoxMultiplayer
		public static final long m_iPhysicsMode = 0xf78; // int
		public static final long m_fMass = 0xf7c; // float
	}

	public static class CPropDoorRotating { // DT_PropDoorRotating
	}

	public static class CBasePropDoor { // DT_BasePropDoor
	}

	public static class CDynamicProp { // DT_DynamicProp
		public static final long m_bUseHitboxesForRenderBox = 0x3024; // int
		public static final long m_flGlowMaxDist = 0x3044; // float
		public static final long m_bShouldGlow = 0x3048; // int
		public static final long m_clrGlow = 0x3049; // int
		public static final long m_nGlowStyle = 0x3050; // int
	}

	public static class CProp_Hallucination { // DT_Prop_Hallucination
		public static final long m_bEnabled = 0x3021; // int
		public static final long m_fVisibleTime = 0x3024; // float
		public static final long m_fRechargeTime = 0x3028; // float
	}

	public static class CPostProcessController { // DT_PostProcessController
		public static final long m_flPostProcessParameters = 0xf68; // float[10] / m_flPostProcessParameters
		public static final long m_bMaster = 0xf94; // int
	}

	public static class CPointWorldText { // DT_PointWorldText
		public static final long m_szText = 0xf98; // const char *
		public static final long m_flTextSize = 0x109c; // float
		public static final long m_textColor = 0x10a0; // int
	}

	public static class CPointCommentaryNode { // DT_PointCommentaryNode
		public static final long m_bActive = 0x3001; // int
		public static final long m_flStartTime = 0x3004; // float
		public static final long m_iszCommentaryFile = 0x3008; // const char *
		public static final long m_iszCommentaryFileNoHDR = 0x310c; // const char *
		public static final long m_iszSpeakers = 0x3210; // const char *
		public static final long m_iNodeNumber = 0x3310; // int
		public static final long m_iNodeNumberMax = 0x3314; // int
		public static final long m_hViewPosition = 0x3320; // int
	}

	public static class CPointCamera { // DT_PointCamera
		public static final long m_FOV = 0xf68; // float
		public static final long m_Resolution = 0xf6c; // float
		public static final long m_bFogEnable = 0xf70; // int
		public static final long m_FogColor = 0xf71; // int
		public static final long m_flFogStart = 0xf78; // float
		public static final long m_flFogEnd = 0xf7c; // float
		public static final long m_flFogMaxDensity = 0xf80; // float
		public static final long m_bActive = 0xf84; // int
		public static final long m_bUseScreenAspectRatio = 0xf85; // int
	}

	public static class CPlayerResource { // DT_PlayerResource
		public static final long m_iKills = 0x12c8; // int[64] / m_iKills
		public static final long m_iAssists = 0x13cc; // int[64] / m_iAssists
		public static final long m_iDeaths = 0x14d0; // int[64] / m_iDeaths
		public static final long m_bConnected = 0x1180; // int[64] / m_bConnected
		public static final long m_iTeam = 0x15d4; // int[64] / m_iTeam
		public static final long m_iPendingTeam = 0x16d8; // int[64] / m_iPendingTeam
		public static final long m_bAlive = 0x17dc; // int[64] / m_bAlive
		public static final long m_iHealth = 0x1820; // int[64] / m_iHealth
		public static final long m_iCoachingTeam = 0x1924; // int[64] / m_iCoachingTeam
	}

	public static class CPlasma { // DT_Plasma
		public static final long m_flStartScale = 0xf68; // float
		public static final long m_flScale = 0xf6c; // float
		public static final long m_flScaleTime = 0xf70; // float
		public static final long m_nFlags = 0xf74; // int
		public static final long m_nPlasmaModelIndex = 0xf78; // int
		public static final long m_nPlasmaModelIndex2 = 0xf7c; // int
		public static final long m_nGlowModelIndex = 0xf80; // int
	}

	public static class CPhysMagnet { // DT_PhysMagnet
	}

	public static class CPhysicsProp { // DT_PhysicsProp
		public static final long m_bAwake = 0x301d; // int
		public static final long m_spawnflags = 0x314; // int
	}

	public static class CStatueProp { // DT_StatueProp
		public static final long m_hInitBaseAnimating = 0x3038; // int
		public static final long m_bShatter = 0x303c; // int
		public static final long m_nShatterFlags = 0x3040; // int
		public static final long m_vShatterPosition = 0x3044; // Vector
		public static final long m_vShatterForce = 0x3050; // Vector
	}

	public static class CPhysBox { // DT_PhysBox
		public static final long m_mass = 0xf68; // float
	}

	public static class CParticleSystem { // DT_ParticleSystem
		public static final long m_fEffects = 0x124; // int
		public static final long m_hOwnerEntity = 0x180; // int
		public static final long moveparent = 0x17c; // int
		public static final long m_iParentAttachment = 0x340; // int
		public static final long m_angRotation = 0x160; // Vector
		public static final long m_iEffectIndex = 0xf68; // int
		public static final long m_bActive = 0xf70; // int
		public static final long m_nStopType = 0xf6c; // int
		public static final long m_flStartTime = 0xf74; // float
		public static final long m_szSnapshotFileName = 0xf78; // const char *
		public static final long m_vServerControlPoints = 0x107c; // Vector[3] / m_vServerControlPoints
		public static final long m_iServerControlPointAssignments = 0x10ac; // int[3] / m_iServerControlPointAssignments
		public static final long m_hControlPointEnts = 0x10d0; // int[62] / m_hControlPointEnts
		public static final long m_iControlPointParents = 0x11cc; // int[62] / m_iControlPointParents
	}

	public static class CMovieDisplay { // DT_MovieDisplay
		public static final long m_bEnabled = 0xf65; // int
		public static final long m_bLooping = 0xf66; // int
		public static final long m_szMovieFilename = 0xf67; // const char *
		public static final long m_szGroupName = 0xfe7; // const char *
		public static final long m_bStretchToFill = 0x1067; // int
		public static final long m_bForcedSlave = 0x1068; // int
		public static final long m_bUseCustomUVs = 0x1069; // int
		public static final long m_flUMin = 0x106c; // float
		public static final long m_flUMax = 0x1070; // float
		public static final long m_flVMin = 0x1074; // float
		public static final long m_flVMax = 0x1078; // float
	}

	public static class CMaterialModifyControl { // DT_MaterialModifyControl
		public static final long m_szMaterialName = 0xf65; // const char *
		public static final long m_szMaterialVar = 0x1064; // const char *
		public static final long m_szMaterialVarValue = 0x1163; // const char *
		public static final long m_iFrameStart = 0x1274; // int
		public static final long m_iFrameEnd = 0x1278; // int
		public static final long m_bWrap = 0x127c; // int
		public static final long m_flFramerate = 0x1280; // float
		public static final long m_bNewAnimCommandsSemaphore = 0x1284; // int
		public static final long m_flFloatLerpStartValue = 0x1288; // float
		public static final long m_flFloatLerpEndValue = 0x128c; // float
		public static final long m_flFloatLerpTransitionTime = 0x1290; // float
		public static final long m_bFloatLerpWrap = 0x1294; // int
		public static final long m_nModifyMode = 0x129c; // int
	}

	public static class CLightGlow { // DT_LightGlow
		public static final long m_nHorizontalSize = 0xf68; // int
		public static final long m_nVerticalSize = 0xf6c; // int
		public static final long m_nMinDist = 0xf70; // int
		public static final long m_nMaxDist = 0xf74; // int
		public static final long m_nOuterMaxDist = 0xf78; // int
		public static final long m_spawnflags = 0xf7c; // int
		public static final long m_vecOrigin = 0x16c; // Vector
		public static final long m_angRotation = 0x160; // Vector
		public static final long moveparent = 0x17c; // int
		public static final long m_flGlowProxySize = 0x1078; // float
		public static final long HDRColorScale = 0x0; // float
	}

	public static class CItemAssaultSuitUseable { // DT_ItemAssaultSuitUseable
		public static final long m_nArmorValue = 0x3e88; // int
		public static final long m_bIsHeavyAssaultSuit = 0x3e8c; // int
	}

	public static class CItem { // DT_Item
		public static final long m_bShouldGlow = 0x3a84; // int
	}

	public static class CInfoOverlayAccessor { // DT_InfoOverlayAccessor
		public static final long m_iOverlayID = 0xf68; // int
	}

	public static class CFuncTrackTrain { // DT_FuncTrackTrain
	}

	public static class CFuncSmokeVolume { // DT_FuncSmokeVolume
		public static final long m_Color1 = 0x10a0; // int
		public static final long m_Color2 = 0x10a4; // int
		public static final long m_MaterialName = 0x10a8; // const char *
		public static final long m_ParticleDrawWidth = 0x11a8; // float
		public static final long m_ParticleSpacingDistance = 0x11ac; // float
		public static final long m_DensityRampSpeed = 0x11b0; // float
		public static final long m_RotationSpeed = 0x11b4; // float
		public static final long m_MovementSpeed = 0x11b8; // float
		public static final long m_Density = 0x11bc; // float
		public static final long m_maxDrawDistance = 0x11c0; // float
		public static final long m_spawnflags = 0x11c4; // int
		public static final long DT_CollisionProperty = 0x378; // Vector[7] / m_Collision
	}

	public static class CFuncRotating { // DT_FuncRotating
		public static final long m_vecOrigin = 0x16c; // Vector
		public static final long m_angRotation_0 = 0x160; // float
		public static final long m_angRotation_1 = 0x164; // float
		public static final long m_angRotation_2 = 0x168; // float
		public static final long m_flSimulationTime = 0x29c; // int
	}

	public static class CFuncReflectiveGlass { // DT_FuncReflectiveGlass
	}

	public static class CFuncOccluder { // DT_FuncOccluder
		public static final long m_bActive = 0xf6c; // int
		public static final long m_nOccluderIndex = 0xf68; // int
	}

	public static class CFuncMoveLinear { // DT_FuncMoveLinear
		public static final long m_vecVelocity = 0x148; // Vector
		public static final long m_fFlags = 0x138; // int
	}

	public static class CFunc_LOD { // DT_Func_LOD
		public static final long m_nDisappearMinDist = 0xf68; // int
		public static final long m_nDisappearMaxDist = 0xf6c; // int
	}

	public static class CTEDust { // DT_TEDust
		public static final long m_flSize = 0x2c; // float
		public static final long m_flSpeed = 0x30; // float
		public static final long m_vecDirection = 0x34; // Vector
	}

	public static class CFunc_Dust { // DT_Func_Dust
		public static final long m_SpawnRate = 0xf6c; // int
		public static final long m_flSizeMin = 0xf70; // float
		public static final long m_flSizeMax = 0xf74; // float
		public static final long m_LifetimeMin = 0xf7c; // int
		public static final long m_LifetimeMax = 0xf80; // int
		public static final long m_DustFlags = 0xf90; // int
		public static final long m_SpeedMax = 0xf78; // int
		public static final long m_DistMax = 0xf84; // int
		public static final long m_nModelIndex = 0x28c; // int
		public static final long m_FallSpeed = 0xf88; // float
		public static final long m_bAffectedByWind = 0xf8c; // int
		public static final long DT_CollisionProperty = 0x378; // Vector[7] / m_Collision
	}

	public static class CFuncConveyor { // DT_FuncConveyor
		public static final long m_flConveyorSpeed = 0xf68; // float
	}

	public static class CFuncBrush { // DT_FuncBrush
	}

	public static class CBreakableSurface { // DT_BreakableSurface
		public static final long m_nNumWide = 0xf70; // int
		public static final long m_nNumHigh = 0xf74; // int
		public static final long m_flPanelWidth = 0xf78; // float
		public static final long m_flPanelHeight = 0xf7c; // float
		public static final long m_vNormal = 0xf80; // Vector
		public static final long m_vCorner = 0xf8c; // Vector
		public static final long m_bIsBroken = 0xf98; // int
		public static final long m_nSurfaceType = 0xf9c; // int
		public static final long m_RawPanelBitVec = 0xfd0; // int[255] / m_RawPanelBitVec
	}

	public static class CFuncAreaPortalWindow { // DT_FuncAreaPortalWindow
		public static final long m_flFadeStartDist = 0xf68; // float
		public static final long m_flFadeDist = 0xf6c; // float
		public static final long m_flTranslucencyLimit = 0xf70; // float
		public static final long m_iBackgroundModelIndex = 0xf74; // int
	}

	public static class CFish { // DT_CFish
		public static final long m_x = 0x3050; // float
		public static final long m_y = 0x3054; // float
		public static final long m_z = 0x3058; // float
		public static final long m_angle = 0x3060; // float
		public static final long m_nModelIndex = 0x28c; // int
		public static final long m_lifeState = 0x293; // int
		public static final long m_waterLevel = 0x3074; // float
	}

	public static class CFireSmoke { // DT_FireSmoke
		public static final long m_flStartScale = 0xf68; // float
		public static final long m_flScale = 0xf6c; // float
		public static final long m_flScaleTime = 0xf70; // float
		public static final long m_nFlags = 0xf74; // int
		public static final long m_nFlameModelIndex = 0xf78; // int
		public static final long m_nFlameFromAboveModelIndex = 0xf7c; // int
	}

	public static class CEntityFlame { // DT_EntityFlame
		public static final long m_hEntAttached = 0xf68; // int
		public static final long m_bCheapEffect = 0xf8c; // int
	}

	public static class CEnvDOFController { // DT_EnvDOFController
		public static final long m_bDOFEnabled = 0xf65; // int
		public static final long m_flNearBlurDepth = 0xf68; // float
		public static final long m_flNearFocusDepth = 0xf6c; // float
		public static final long m_flFarFocusDepth = 0xf70; // float
		public static final long m_flFarBlurDepth = 0xf74; // float
		public static final long m_flNearBlurRadius = 0xf78; // float
		public static final long m_flFarBlurRadius = 0xf7c; // float
	}

	public static class CEnvTonemapController { // DT_EnvTonemapController
		public static final long m_bUseCustomAutoExposureMin = 0xf65; // int
		public static final long m_bUseCustomAutoExposureMax = 0xf66; // int
		public static final long m_bUseCustomBloomScale = 0xf67; // int
		public static final long m_flCustomAutoExposureMin = 0xf68; // float
		public static final long m_flCustomAutoExposureMax = 0xf6c; // float
		public static final long m_flCustomBloomScale = 0xf70; // float
		public static final long m_flCustomBloomScaleMinimum = 0xf74; // float
		public static final long m_flBloomExponent = 0xf78; // float
		public static final long m_flBloomSaturation = 0xf7c; // float
		public static final long m_flTonemapPercentTarget = 0xf80; // float
		public static final long m_flTonemapPercentBrightPixels = 0xf84; // float
		public static final long m_flTonemapMinAvgLum = 0xf88; // float
		public static final long m_flTonemapRate = 0xf8c; // float
	}

	public static class CEnvScreenEffect { // DT_EnvScreenEffect
		public static final long m_flDuration = 0xf68; // float
		public static final long m_nType = 0xf6c; // int
	}

	public static class CEnvScreenOverlay { // DT_EnvScreenOverlay
		public static final long m_iszOverlayNames_0 = 0xf65; // const char *
		public static final long m_iszOverlayNames = 0x0; // array elements: 10
		public static final long m_flOverlayTimes_0 = 0x195c; // float
		public static final long m_flOverlayTimes = 0x0; // array elements: 10
		public static final long m_flStartTime = 0x1984; // float
		public static final long m_iDesiredOverlay = 0x1988; // int
		public static final long m_bIsActive = 0x198c; // int
	}

	public static class CEnvProjectedTexture { // DT_EnvProjectedTexture
		public static final long m_hTargetEntity = 0xf6c; // int
		public static final long m_bState = 0xf70; // int
		public static final long m_bAlwaysUpdate = 0xf71; // int
		public static final long m_flLightFOV = 0xf74; // float
		public static final long m_bEnableShadows = 0xf78; // int
		public static final long m_bSimpleProjection = 0xf79; // int
		public static final long m_bLightOnlyTarget = 0xf7a; // int
		public static final long m_bLightWorld = 0xf7b; // int
		public static final long m_bCameraSpace = 0xf7c; // int
		public static final long m_flBrightnessScale = 0xf80; // float
		public static final long m_LightColor = 0xf84; // int
		public static final long m_flColorTransitionTime = 0xf98; // float
		public static final long m_flAmbient = 0xf9c; // float
		public static final long m_SpotlightTextureName = 0xfa8; // const char *
		public static final long m_nSpotlightTextureFrame = 0x10c0; // int
		public static final long m_flNearZ = 0xfa0; // float
		public static final long m_flFarZ = 0xfa4; // float
		public static final long m_nShadowQuality = 0x10c4; // int
		public static final long m_flProjectionSize = 0x10d8; // float
		public static final long m_flRotation = 0x10dc; // float
		public static final long m_iStyle = 0x10c8; // int
	}

	public static class CEnvParticleScript { // DT_EnvParticleScript
		public static final long m_flSequenceScale = 0x3138; // float
	}

	public static class CFogController { // DT_FogController
		public static final long m_fog_blend = 0xfb1; // int
		public static final long m_fog_dirPrimary = 0xf70; // Vector
		public static final long m_fog_colorPrimary = 0xf7c; // int
		public static final long m_fog_colorSecondary = 0xf80; // int
		public static final long m_fog_start = 0xf8c; // float
		public static final long m_fog_end = 0xf90; // float
		public static final long m_fog_farz = 0xf94; // float
		public static final long m_fog_maxdensity = 0xf98; // float
		public static final long m_fog_colorPrimaryLerpTo = 0xf84; // int
		public static final long m_fog_colorSecondaryLerpTo = 0xf88; // int
		public static final long m_fog_startLerpTo = 0xf9c; // float
		public static final long m_fog_endLerpTo = 0xfa0; // float
		public static final long m_fog_maxdensityLerpTo = 0xfa4; // float
		public static final long m_fog_lerptime = 0xfa8; // float
		public static final long m_fog_duration = 0xfac; // float
		public static final long m_fog_HDRColorScale = 0xfb8; // float
		public static final long m_fog_ZoomFogScale = 0xfb4; // float
	}

	public static class CCascadeLight { // DT_CascadeLight
		public static final long m_shadowDirection = 0xf68; // Vector
		public static final long m_envLightShadowDirection = 0xf74; // Vector
		public static final long m_bEnabled = 0xf80; // int
		public static final long m_bUseLightEnvAngles = 0xf81; // int
		public static final long m_LightColor = 0xf82; // int
		public static final long m_LightColorScale = 0xf88; // int
		public static final long m_flMaxShadowDist = 0xf8c; // float
	}

	public static class CEnvAmbientLight { // DT_EnvAmbientLight
		public static final long m_vecColor = 0x1090; // Vector
	}

	public static class CEntityParticleTrail { // DT_EntityParticleTrail
		public static final long m_iMaterialName = 0x1098; // int
		public static final long DT_EntityParticleTrailInfo = 0x10a0; // float[2] / m_Info
		public static final long m_hConstraintEntity = 0x10c0; // int
	}

	public static class CEntityFreezing { // DT_EntityFreezing
		public static final long m_vFreezingOrigin = 0xf68; // Vector
		public static final long m_flFrozenPerHitbox = 0xf74; // float[49] / m_flFrozenPerHitbox
		public static final long m_flFrozen = 0x103c; // float
		public static final long m_bFinishFreezing = 0x1040; // int
	}

	public static class CEntityDissolve { // DT_EntityDissolve
		public static final long m_flStartTime = 0xf70; // float
		public static final long m_flFadeOutStart = 0xf74; // float
		public static final long m_flFadeOutLength = 0xf78; // float
		public static final long m_flFadeOutModelStart = 0xf7c; // float
		public static final long m_flFadeOutModelLength = 0xf80; // float
		public static final long m_flFadeInStart = 0xf84; // float
		public static final long m_flFadeInLength = 0xf88; // float
		public static final long m_nDissolveType = 0xf8c; // int
		public static final long m_vDissolverOrigin = 0xf94; // Vector
		public static final long m_nMagnitude = 0xfa0; // int
	}

	public static class CDynamicLight { // DT_DynamicLight
		public static final long m_Flags = 0xf65; // int
		public static final long m_LightStyle = 0xf66; // int
		public static final long m_Radius = 0xf68; // float
		public static final long m_Exponent = 0xf6c; // int
		public static final long m_InnerAngle = 0xf70; // float
		public static final long m_OuterAngle = 0xf74; // float
		public static final long m_SpotRadius = 0xf78; // float
	}

	public static class CColorCorrectionVolume { // DT_ColorCorrectionVolume
		public static final long m_bEnabled = 0xfa4; // int
		public static final long m_MaxWeight = 0xfa8; // float
		public static final long m_FadeDuration = 0xfac; // float
		public static final long m_Weight = 0xfb0; // float
		public static final long m_lookupFilename = 0xfb4; // const char *
	}

	public static class CColorCorrection { // DT_ColorCorrection
		public static final long m_vecOrigin = 0xf68; // Vector
		public static final long m_minFalloff = 0xf74; // float
		public static final long m_maxFalloff = 0xf78; // float
		public static final long m_flCurWeight = 0xf88; // float
		public static final long m_flMaxWeight = 0xf84; // float
		public static final long m_flFadeInDuration = 0xf7c; // float
		public static final long m_flFadeOutDuration = 0xf80; // float
		public static final long m_netLookupFilename = 0xf8c; // const char *
		public static final long m_bEnabled = 0x1090; // int
		public static final long m_bMaster = 0x1091; // int
		public static final long m_bClientSide = 0x1092; // int
		public static final long m_bExclusive = 0x1093; // int
	}

	public static class CBreakableProp { // DT_BreakableProp
		public static final long m_qPreferredPlayerCarryAngles = 0x3010; // Vector
		public static final long m_bClientPhysics = 0x301c; // int
	}

	public static class CBeamSpotlight { // DT_BeamSpotlight
		public static final long m_nHaloIndex = 0xf68; // int
		public static final long m_bSpotlightOn = 0xf74; // int
		public static final long m_bHasDynamicLight = 0xf75; // int
		public static final long m_flSpotlightMaxLength = 0xf78; // float
		public static final long m_flSpotlightGoalWidth = 0xf7c; // float
		public static final long m_flHDRColorScale = 0xf80; // float
		public static final long m_nRotationAxis = 0xf6c; // int
		public static final long m_flRotationSpeed = 0xf70; // float
	}

	public static class CBaseButton { // DT_BaseButton
		public static final long m_usable = 0xf91; // int
	}

	public static class CBaseToggle { // DT_BaseToggle
		public static final long m_vecFinalDest = 0xf7c; // Vector
		public static final long m_movementType = 0xf88; // int
		public static final long m_flMoveTargetTime = 0xf8c; // float
	}

	public static class CBasePlayer { // DT_BasePlayer
		public static final long DT_LocalPlayerExclusive = 0x0; // int[23] / localdata
		public static final long DT_PlayerState = 0x3980; // int[0] / pl
		public static final long m_iFOV = 0x3998; // int
		public static final long m_iFOVStart = 0x399c; // int
		public static final long m_flFOVTime = 0x39bc; // float
		public static final long m_iDefaultFOV = 0x3af4; // int
		public static final long m_hZoomOwner = 0x39f4; // int
		public static final long m_afPhysicsFlags = 0x3aa8; // int
		public static final long m_hVehicle = 0x3aac; // int
		public static final long m_hUseEntity = 0x3af0; // int
		public static final long m_hGroundEntity = 0x184; // int
		public static final long m_iHealth = 0x134; // int
		public static final long m_lifeState = 0x293; // int
		public static final long m_iAmmo = 0x34a8; // int[31] / m_iAmmo
		public static final long m_iBonusProgress = 0x39e8; // int
		public static final long m_iBonusChallenge = 0x39ec; // int
		public static final long m_flMaxspeed = 0x39f0; // float
		public static final long m_fFlags = 0x138; // int
		public static final long m_iObserverMode = 0x3b40; // int
		public static final long m_bActiveCameraMan = 0x3b44; // int
		public static final long m_bCameraManXRay = 0x3b45; // int
		public static final long m_bCameraManOverview = 0x3b46; // int
		public static final long m_bCameraManScoreBoard = 0x3b47; // int
		public static final long m_uCameraManGraphs = 0x3b48; // int
		public static final long m_iDeathPostEffect = 0x3b3c; // int
		public static final long m_hObserverTarget = 0x3b54; // int
		public static final long m_hViewModel_0 = 0x3ab4; // int
		public static final long m_hViewModel = 0x0; // array elements: 2
		public static final long m_iCoachingTeam = 0x367c; // int
		public static final long m_szLastPlaceName = 0x3dc0; // const char *
		public static final long m_vecLadderNormal = 0x39d8; // Vector
		public static final long m_ladderSurfaceProps = 0x39b4; // int
		public static final long m_ubEFNoInterpParity = 0x3de8; // int
		public static final long m_hPostProcessCtrl = 0x4000; // int
		public static final long m_hColorCorrectionCtrl = 0x4004; // int
		public static final long m_PlayerFog_m_hCtrl = 0x4010; // int
		public static final long m_vphysicsCollisionState = 0x3a10; // int
		public static final long m_hViewEntity = 0x3b08; // int
		public static final long m_bShouldDrawPlayerWhileUsingViewEntity = 0x3b0c; // int
		public static final long m_flDuckAmount = 0x36e0; // float
		public static final long m_flDuckSpeed = 0x36e4; // float
		public static final long m_nWaterLevel = 0x292; // int
	}

	public static class CBaseFlex { // DT_BaseFlex
		public static final long m_flexWeight = 0x30d8; // float[95] / m_flexWeight
		public static final long m_blinktoggle = 0x32a0; // int
		public static final long m_viewtarget = 0x3084; // Vector
	}

	public static class CBaseEntity { // DT_BaseEntity
		public static final long m_flSimulationTime = 0x29c; // int
		public static final long m_cellbits = 0xac; // int
		public static final long m_cellX = 0xb4; // int
		public static final long m_cellY = 0xb8; // int
		public static final long m_cellZ = 0xbc; // int
		public static final long m_vecOrigin = 0x16c; // Vector
		public static final long m_angRotation = 0x160; // Vector
		public static final long m_nModelIndex = 0x28c; // int
		public static final long m_fEffects = 0x124; // int
		public static final long m_nRenderMode = 0x28f; // int
		public static final long m_nRenderFX = 0x28e; // int
		public static final long m_clrRender = 0xa8; // int
		public static final long m_iTeamNum = 0x128; // int
		public static final long m_iPendingTeamNum = 0x12c; // int
		public static final long m_CollisionGroup = 0x548; // int
		public static final long m_flElasticity = 0x420; // float
		public static final long m_flShadowCastDistance = 0x424; // float
		public static final long m_hOwnerEntity = 0x180; // int
		public static final long m_hEffectEntity = 0xf28; // int
		public static final long moveparent = 0x17c; // int
		public static final long m_iParentAttachment = 0x340; // int
		public static final long m_iName = 0x188; // const char *
		public static final long movetype = 0x0; // int
		public static final long movecollide = 0x0; // int
		public static final long DT_CollisionProperty = 0x378; // Vector[7] / m_Collision
		public static final long m_iTextureFrameIndex = 0xf1c; // int
		public static final long m_bSimulatedEveryTick = 0xeca; // int
		public static final long m_bAnimatedEveryTick = 0xecb; // int
		public static final long m_bAlternateSorting = 0xecc; // int
		public static final long m_bSpotted = 0xecd; // int
		public static final long m_bSpottedBy = 0xece; // int[64] / m_bSpottedBy
		public static final long m_bSpottedByMask = 0xf10; // int[1] / m_bSpottedByMask
		public static final long m_bIsAutoaimTarget = 0x90; // int
		public static final long m_fadeMinDist = 0x348; // float
		public static final long m_fadeMaxDist = 0x34c; // float
		public static final long m_flFadeScale = 0x350; // float
		public static final long m_nMinCPULevel = 0xf18; // int
		public static final long m_nMaxCPULevel = 0xf19; // int
		public static final long m_nMinGPULevel = 0xf1a; // int
		public static final long m_nMaxGPULevel = 0xf1b; // int
		public static final long m_flUseLookAtAngle = 0x318; // float
		public static final long m_flLastMadeNoiseTime = 0x40; // float
	}

	public static class CBaseDoor { // DT_BaseDoor
		public static final long m_flWaveHeight = 0xf94; // float
	}

	public static class CBaseCombatCharacter { // DT_BaseCombatCharacter
		public static final long DT_BCCLocalPlayerExclusive = 0x0; // float[0] / bcc_localdata
		public static class DT_BCCNonLocalPlayerExclusive { // m_hMyWeapons
		}

		public static final long DT_BCCNonLocalPlayerExclusive = 0x0; // DataTable[0] / bcc_nonlocaldata
		public static final long m_LastHitGroup = 0x34a4; // int
		public static final long m_hActiveWeapon = 0x3628; // int
		public static final long m_flTimeOfLastInjury = 0x362c; // float
		public static final long m_nRelativeDirectionOfLastInjury = 0x3630; // int
		public static final long m_hMyWeapons = 0x3528; // int[63] / m_hMyWeapons
		public static final long m_hMyWearables = 0x3634; // int[0] / m_hMyWearables
	}

	public static class CBaseAnimatingOverlay { // DT_BaseAnimatingOverlay
		public static class DT_OverlayVars { // _ST_m_AnimOverlay_15
		}

		public static final long DT_OverlayVars = 0x0; // DataTable[0] / overlay_vars
	}

	public static class CBoneFollower { // DT_BoneFollower
		public static final long m_modelIndex = 0xf68; // int
		public static final long m_solidIndex = 0xf6c; // int
	}

	public static class CBaseAnimating { // DT_BaseAnimating
		public static final long m_nSequence = 0x2ee8; // int
		public static final long m_nForceBone = 0x2c44; // int
		public static final long m_vecForce = 0x2c38; // Vector
		public static final long m_nSkin = 0xfd8; // int
		public static final long m_nBody = 0xfdc; // int
		public static final long m_nHitboxSet = 0xfa8; // int
		public static final long m_flModelScale = 0x2d30; // float
		public static final long m_flPoseParameter = 0x2d68; // float[23] / m_flPoseParameter
		public static final long m_flPlaybackRate = 0xfd4; // float
		public static final long m_flEncodedController = 0x1004; // float[3] / m_flEncodedController
		public static final long m_bClientSideAnimation = 0x2ec8; // int
		public static final long m_bClientSideFrameReset = 0x2c8c; // int
		public static final long m_bClientSideRagdoll = 0x2ad; // int
		public static final long m_nNewSequenceParity = 0xff4; // int
		public static final long m_nResetEventsParity = 0xff8; // int
		public static final long m_nMuzzleFlashParity = 0x1014; // int
		public static final long m_hLightingOrigin = 0x2fb8; // int
		public static final long DT_ServerAnimationData = 0x0; // float[0] / serveranimdata
		public static final long m_flFrozen = 0x2cd0; // float
		public static final long m_ScaleType = 0x2d34; // int
		public static final long m_bSuppressAnimSounds = 0x2fbe; // int
	}

	public static class CAI_BaseNPC { // DT_AI_BaseNPC
		public static final long m_lifeState = 0x293; // int
		public static final long m_bPerformAvoidance = 0x3650; // int
		public static final long m_bIsMoving = 0x3651; // int
		public static final long m_bFadeCorpse = 0x3652; // int
		public static final long m_iDeathPose = 0x3640; // int
		public static final long m_iDeathFrame = 0x3644; // int
		public static final long m_iSpeedModRadius = 0x3648; // int
		public static final long m_iSpeedModSpeed = 0x364c; // int
		public static final long m_bSpeedModActive = 0x3653; // int
		public static final long m_bImportanRagdoll = 0x3654; // int
		public static final long m_flTimePingEffect = 0x363c; // float
	}

	public static class CBeam { // DT_Beam
		public static final long m_nBeamFlags = 0xf88; // int
		public static final long m_nNumBeamEnts = 0xf78; // int
		public static final long m_hAttachEntity = 0xf8c; // int[9] / m_hAttachEntity
		public static final long m_nAttachIndex = 0xfb4; // int[9] / m_nAttachIndex
		public static final long m_nHaloIndex = 0xf80; // int
		public static final long m_fHaloScale = 0xfe8; // float
		public static final long m_fWidth = 0xfdc; // float
		public static final long m_fEndWidth = 0xfe0; // float
		public static final long m_fFadeLength = 0xfe4; // float
		public static final long m_fAmplitude = 0xfec; // float
		public static final long m_fStartFrame = 0xff0; // float
		public static final long m_fSpeed = 0xff4; // float
		public static final long m_flFrameRate = 0xf68; // float
		public static final long m_flHDRColorScale = 0xf6c; // float
		public static final long m_clrRender = 0xa8; // int
		public static final long m_nRenderFX = 0x28e; // int
		public static final long m_nRenderMode = 0x28f; // int
		public static final long m_flFrame = 0xff8; // float
		public static final long m_nClipStyle = 0xffc; // int
		public static final long m_vecEndPos = 0x1000; // Vector
		public static final long m_nModelIndex = 0x28c; // int
		public static final long m_vecOrigin = 0x16c; // Vector
		public static final long moveparent = 0x17c; // int
	}

	public static class CBaseViewModel { // DT_BaseViewModel
		public static final long m_hWeapon = 0x3060; // int
		public static final long m_nSkin = 0xfd8; // int
		public static final long m_nBody = 0xfdc; // int
		public static final long m_nSequence = 0x2ee8; // int
		public static final long m_nViewModelIndex = 0x3058; // int
		public static final long m_flPlaybackRate = 0xfd4; // float
		public static final long m_fEffects = 0x124; // int
		public static final long m_nAnimationParity = 0x305c; // int
		public static final long m_hOwner = 0x3064; // int
		public static final long m_nNewSequenceParity = 0xff4; // int
		public static final long m_nResetEventsParity = 0xff8; // int
		public static final long m_nMuzzleFlashParity = 0x1014; // int
		public static final long m_bShouldIgnoreOffsetAndAccuracy = 0x301c; // int
	}

	public static class CBaseParticleEntity { // DT_BaseParticleEntity
	}

	public static class CBaseGrenade { // DT_BaseGrenade
		public static final long m_flDamage = 0x3018; // float
		public static final long m_DmgRadius = 0x3004; // float
		public static final long m_bIsLive = 0x3002; // int
		public static final long m_hThrower = 0x3028; // int
		public static final long m_vecVelocity = 0x148; // Vector
		public static final long m_fFlags = 0x138; // int
	}

	public static class CBaseCombatWeapon { // DT_BaseCombatWeapon
		public static final long DT_LocalWeaponData = 0x0; // int[5] / LocalWeaponData
		public static final long DT_LocalActiveWeaponData = 0x0; // float[3] / LocalActiveWeaponData
		public static final long m_iViewModelIndex = 0x3a90; // int
		public static final long m_iWorldModelIndex = 0x3a94; // int
		public static final long m_iWorldDroppedModelIndex = 0x3a98; // int
		public static final long m_iState = 0x3aa8; // int
		public static final long m_hOwner = 0x3a80; // int
		public static final long m_iClip1 = 0x3ab4; // int
		public static final long m_iClip2 = 0x3ab8; // int
		public static final long m_iPrimaryReserveAmmoCount = 0x3abc; // int
		public static final long m_iSecondaryReserveAmmoCount = 0x3ac0; // int
		public static final long m_hWeaponWorldModel = 0x3aa4; // int
		public static final long m_iNumEmptyAttacks = 0x3aa0; // int
	}

	public static class CBaseWeaponWorldModel { // DT_BaseWeaponWorldModel
		public static final long m_nBody = 0xfdc; // int
		public static final long m_fEffects = 0x124; // int
		public static final long moveparent = 0x17c; // int
		public static final long m_hCombatWeaponParent = 0x3084; // int
	}

	public static class CFuncMonitor { // DT_FuncMonitor
	}

}
