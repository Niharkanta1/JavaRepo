package me.lixko.csgoexternals.util;

public enum TextAlign {
	CENTER,
	RIGHT,
	LEFT;
}
